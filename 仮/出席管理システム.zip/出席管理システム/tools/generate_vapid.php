<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("CLIから実行してください。\n");
}

if (!extension_loaded('openssl')) {
    fwrite(STDERR, "OpenSSL拡張機能が必要です。\n");
    exit(1);
}

$config = [
    'private_key_type' => OPENSSL_KEYTYPE_EC,
    'curve_name' => 'prime256v1',
];

$key = openssl_pkey_new($config);

if ($key === false) {
    fwrite(STDERR, "VAPID鍵の生成に失敗しました。\n");
    exit(1);
}

$details = openssl_pkey_get_details($key);

if (
    !is_array($details) ||
    !isset($details['ec']['d'], $details['ec']['x'], $details['ec']['y'])
) {
    fwrite(STDERR, "鍵の詳細を取得できませんでした。\n");
    exit(1);
}

function mcas_base64url_encode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

$privateBin = (string)$details['ec']['d'];
$xBin = (string)$details['ec']['x'];
$yBin = (string)$details['ec']['y'];

$privateBin = str_pad($privateBin, 32, "\0", STR_PAD_LEFT);
$xBin = str_pad($xBin, 32, "\0", STR_PAD_LEFT);
$yBin = str_pad($yBin, 32, "\0", STR_PAD_LEFT);

if (strlen($privateBin) !== 32 || strlen($xBin) !== 32 || strlen($yBin) !== 32) {
    fwrite(STDERR, "生成された鍵の長さが想定と異なります。\n");
    exit(1);
}

$privateKey = mcas_base64url_encode($privateBin);
$publicKey = mcas_base64url_encode("\x04" . $xBin . $yBin);

$projectRoot = dirname(__DIR__);
$storageDir = $projectRoot . '/private_storage';

if (!is_dir($storageDir) && !mkdir($storageDir, 0700, true) && !is_dir($storageDir)) {
    fwrite(STDERR, "private_storageフォルダを作成できません。\n");
    exit(1);
}

$target = $storageDir . '/vapid_keys.php';
$temp = $target . '.tmp-' . bin2hex(random_bytes(8));

$content = "<?php\n"
    . "declare(strict_types=1);\n\n"
    . "return " . var_export([
        'public_key' => $publicKey,
        'private_key' => $privateKey,
    ], true) . ";\n";

if (file_put_contents($temp, $content, LOCK_EX) === false) {
    @unlink($temp);
    fwrite(STDERR, "鍵ファイルを書き込めません。\n");
    exit(1);
}

chmod($temp, 0600);

if (!rename($temp, $target)) {
    @unlink($temp);
    fwrite(STDERR, "鍵ファイルを保存できません。\n");
    exit(1);
}

chmod($target, 0600);

echo "VAPID鍵を private_storage/vapid_keys.php に保存しました。\n";
echo "公開鍵（ブラウザー設定用）：\n";
echo $publicKey . "\n";
echo "秘密鍵は画面に表示しません。ファイルを公開したり、他人に送ったりしないでください。\n";