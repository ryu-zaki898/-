<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

function mcas_require_meeting_admin(): void
{
    mcas_require_login();

    if (($_SESSION['role'] ?? '') === 'system_admin') {
        return;
    }

    $tenantId = $_SESSION['tenant_id'] ?? null;
    $userId = (int)($_SESSION['user_id'] ?? 0);

    if ($tenantId === null || $userId < 1) {
        http_response_code(403);
        exit('会議リンクを管理する権限がありません。');
    }

    $stmt = mcas_db()->prepare(
        'SELECT 1
         FROM organization_admins
         WHERE organization_id = :organization_id
           AND user_id = :user_id
         LIMIT 1'
    );
    $stmt->execute([
        ':organization_id' => (int)$tenantId,
        ':user_id' => $userId,
    ]);

    if (!$stmt->fetchColumn()) {
        http_response_code(403);
        exit('会議リンクを管理する権限がありません。');
    }
}

function mcas_validate_meeting_url(string $url): string
{
    $url = trim($url);

    if (
        $url === '' ||
        strlen($url) > 2048 ||
        !filter_var($url, FILTER_VALIDATE_URL)
    ) {
        throw new RuntimeException('有効な会議URLを入力してください。');
    }

    $parts = parse_url($url);
    $scheme = strtolower((string)($parts['scheme'] ?? ''));

    if (
        !in_array($scheme, ['http', 'https'], true) ||
        empty($parts['host']) ||
        isset($parts['user']) ||
        isset($parts['pass'])
    ) {
        throw new RuntimeException('会議URLは http:// または https:// で入力してください。');
    }

    return $url;
}