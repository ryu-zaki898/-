<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

/**
 * ログイン済みか確認します。
 */
function mcas_is_logged_in(): bool
{
    return isset($_SESSION['user_id']) && (int)$_SESSION['user_id'] > 0;
}

/**
 * ログインを要求します。
 */
function mcas_require_login(): void
{
    if (!mcas_is_logged_in()) {
        header('Location: /login.php');
        exit;
    }
}

/**
 * 指定した権限のいずれかを要求します。
 */
function mcas_require_role(array $allowedRoles): void
{
    mcas_require_login();

    $role = (string)($_SESSION['role'] ?? '');

    if (!in_array($role, $allowedRoles, true)) {
        http_response_code(403);
        exit('この操作を行う権限がありません。');
    }
}