<?php
declare(strict_types=1);

return [
    'app_name' => 'MyControlAssociationSystem',

    // Xserverで使うデータベース情報に置き換えてください。
    'db' => [
        'host' => 'localhost',
        'name' => 'データベース名',
        'user' => 'データベースユーザー名',
        'password' => 'データベースパスワード',
        'charset' => 'utf8mb4',
    ],

    // public_htmlの外に置く保存フォルダ
    'storage_path' => dirname(__DIR__, 2) . '/private_storage',

    // 第7部で設定します。秘密鍵は公開ページに出さないでください。
    'vapid' => [
        'subject' => 'mailto:hakai898895@gmail.com',
        'public_key' => '',
        'private_key' => '',
        'setup_key' => 'passwordislong',
    ],
];