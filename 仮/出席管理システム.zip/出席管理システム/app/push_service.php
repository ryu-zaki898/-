<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

function mcas_push_library_available(): bool
{
    $autoload = dirname(__DIR__) . '/vendor/autoload.php';

    if (!is_file($autoload)) {
        return false;
    }

    require_once $autoload;

    return class_exists(\Minishlink\WebPush\WebPush::class)
        && class_exists(\Minishlink\WebPush\Subscription::class);
}

/**
 * ログイン中の利用者に通知を記録し、登録済み端末へPush送信します。
 */
function mcas_send_push_to_user(
    int $userId,
    int $tenantId,
    string $title,
    string $body
): array {
    if (!mcas_push_library_available()) {
        throw new RuntimeException('Push通知ライブラリが見つかりません。');
    }

    $config = $GLOBALS['config'] ?? [];
    $vapid = $config['vapid'] ?? [];

    $subject = (string)($vapid['subject'] ?? '');
    $publicKey = (string)($vapid['public_key'] ?? '');
    $privateKey = (string)($vapid['private_key'] ?? '');

    if (
        $subject === '' ||
        $publicKey === '' ||
        $privateKey === '' ||
        !filter_var(substr($subject, 7), FILTER_VALIDATE_EMAIL)
    ) {
        throw new RuntimeException('VAPID設定を確認してください。');
    }

    $pdo = mcas_db();

    $stmt = $pdo->prepare(
        'INSERT INTO notifications
            (tenant_id, target_user_id, type, title, body, is_read)
         VALUES
            (:tenant_id, :user_id, :type, :title, :body, 0)'
    );
    $stmt->execute([
        ':tenant_id' => $tenantId,
        ':user_id' => $userId,
        ':type' => 'push_test',
        ':title' => $title,
        ':body' => $body,
    ]);

    $stmt = $pdo->prepare(
        'SELECT id, endpoint, p256dh_key, auth_key, content_encoding
         FROM push_subscriptions
         WHERE user_id = :user_id AND tenant_id = :tenant_id'
    );
    $stmt->execute([
        ':user_id' => $userId,
        ':tenant_id' => $tenantId,
    ]);
    $subscriptions = $stmt->fetchAll();

    if (!$subscriptions) {
        return [
            'sent' => 0,
            'failed' => 0,
            'message' => '通知はアプリ内に保存しましたが、購読端末がありません。',
        ];
    }

    $webPush = new \Minishlink\WebPush\WebPush([
        'VAPID' => [
            'subject' => $subject,
            'publicKey' => $publicKey,
            'privateKey' => $privateKey,
        ],
    ]);

    $payload = json_encode([
        'title' => $title,
        'body' => $body,
        'url' => '/notifications/',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if (!is_string($payload)) {
        throw new RuntimeException('通知データを作成できません。');
    }

    $sent = 0;
    $failed = 0;

    foreach ($subscriptions as $row) {
        $subscription = \Minishlink\WebPush\Subscription::create([
            'endpoint' => (string)$row['endpoint'],
            'publicKey' => (string)$row['p256dh_key'],
            'authToken' => (string)$row['auth_key'],
            'contentEncoding' => (string)$row['content_encoding'],
        ]);

        try {
            $report = $webPush->sendOneNotification($subscription, $payload);

            if ($report->isSuccess()) {
                $sent++;
                continue;
            }

            $failed++;
            $response = $report->getResponse();
            $statusCode = $response ? (int)$response->getStatusCode() : 0;

            // ブラウザー側で購読が無効になった場合は登録を削除します。
            if (in_array($statusCode, [404, 410], true)) {
                $delete = $pdo->prepare(
                    'DELETE FROM push_subscriptions WHERE id = :id'
                );
                $delete->execute([':id' => (int)$row['id']]);
            }
        } catch (Throwable $e) {
            $failed++;
            error_log('MCAS Web Push error: ' . $e->getMessage());
        }
    }

    return [
        'sent' => $sent,
        'failed' => $failed,
        'message' => "Push送信成功 {$sent} 件、失敗 {$failed} 件です。",
    ];
}