<?php
declare(strict_types=1);

require_once __DIR__ . '/file_manager.php';

function mcas_find_share(string $token): ?array
{
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
        return null;
    }

    $stmt = mcas_db()->prepare(
        'SELECT s.id AS share_id, s.token_hash, s.permission,
                s.password_hash, s.expires_at, s.is_active,
                f.id AS file_id, f.display_name, f.storage_key,
                f.mime_type, f.file_size
         FROM mcas_file_shares s
         INNER JOIN mcas_storage_items f ON f.id = s.storage_item_id
         WHERE s.token_hash = :token_hash
           AND f.item_type = :item_type
         LIMIT 1'
    );
    $stmt->execute([
        ':token_hash' => hash('sha256', $token),
        ':item_type' => 'file',
    ]);

    $share = $stmt->fetch();

    if (!$share || (int)$share['is_active'] !== 1) {
        return null;
    }

    if (
        $share['expires_at'] !== null &&
        strtotime((string)$share['expires_at']) < time()
    ) {
        return null;
    }

    return $share;
}

function mcas_share_password_unlocked(array $share): bool
{
    if (empty($share['password_hash'])) {
        return true;
    }

    return !empty($_SESSION['mcas_share_unlocked'][(int)$share['share_id']]);
}

function mcas_require_share_password(array $share): void
{
    if (mcas_share_password_unlocked($share)) {
        return;
    }

    if (
        $_SERVER['REQUEST_METHOD'] === 'POST' &&
        isset($_POST['share_password'])
    ) {
        mcas_verify_csrf();

        if (password_verify(
            (string)$_POST['share_password'],
            (string)$share['password_hash']
        )) {
            $_SESSION['mcas_share_unlocked'][(int)$share['share_id']] = true;
            return;
        }
    }

    http_response_code(200);
    ?>
    <!doctype html>
    <html lang="ja">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>共有ファイルの確認</title>
    </head>
    <body>
    <main>
        <h1>共有ファイル</h1>
        <p>この共有ファイルにはパスワードが設定されています。</p>
        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
            <p role="alert">パスワードが違います。</p>
        <?php endif; ?>
        <form method="post">
            <input type="hidden" name="csrf_token"
                   value="<?= htmlspecialchars(mcas_csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
            <label>パスワード
                <input type="password" name="share_password" required>
            </label>
            <button type="submit">確認</button>
        </form>
    </main>
    </body>
    </html>
    <?php
    exit;
}