<?php
declare(strict_types=1);

$configFile = __DIR__ . '/config/app.php';

if (!is_file($configFile)) {
    http_response_code(500);
    exit('アプリ設定ファイルが見つかりません。');
}

$config = require $configFile;

if (!is_array($config) || empty($config['db'])) {
    http_response_code(500);
    exit('アプリ設定を確認してください。');
}

define('MCAS_APP_NAME', (string)($config['app_name'] ?? 'MyControlAssociationSystem'));
define('MCAS_ROOT', dirname(__DIR__));
define('MCAS_STORAGE_PATH', (string)($config['storage_path'] ?? MCAS_ROOT . '/private_storage'));

$isHttps = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== '' && $_SERVER['HTTPS'] !== 'off';

if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_start();
}

/**
 * HTMLに出力する文字列をエスケープします。
 */
function mcas_e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * PDO接続を取得します。
 */
function mcas_db(): PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $config = $GLOBALS['config']['db'] ?? null;

    if (!is_array($config)) {
        throw new RuntimeException('データベース設定が見つかりません。');
    }

    $host = (string)($config['host'] ?? 'localhost');
    $name = (string)($config['name'] ?? '');
    $user = (string)($config['user'] ?? '');
    $password = (string)($config['password'] ?? '');
    $charset = (string)($config['charset'] ?? 'utf8mb4');

    if ($name === '' || $user === '') {
        throw new RuntimeException('DB名とDBユーザー名を設定してください。');
    }

    $dsn = "mysql:host={$host};dbname={$name};charset={$charset}";

    $pdo = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    return $pdo;
}

/**
 * CSRFトークンを取得します。フォームのhidden項目に入れてください。
 */
function mcas_csrf_token(): string
{
    if (empty($_SESSION['mcas_csrf_token'])) {
        $_SESSION['mcas_csrf_token'] = bin2hex(random_bytes(32));
    }

    return (string)$_SESSION['mcas_csrf_token'];
}

/**
 * POSTフォームのCSRFトークンを検証します。
 */
function mcas_verify_csrf(): void
{
    $posted = $_POST['csrf_token'] ?? '';
    $saved = $_SESSION['mcas_csrf_token'] ?? '';

    if (
        !is_string($posted) ||
        !is_string($saved) ||
        $posted === '' ||
        $saved === '' ||
        !hash_equals($saved, $posted)
    ) {
        http_response_code(403);
        exit('フォームの有効期限が切れました。ページを再読み込みしてください。');
    }
}

/**
 * ログインが必要なページで使います。
 * ログイン画面は第3部で作成します。
 */
function mcas_require_login(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: /login.php');
        exit;
    }
}
$config = require $configFile;
$GLOBALS['config'] = $config;