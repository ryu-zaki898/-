<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

/**
 * 保存先を作り、公開フォルダの外にあることを確認します。
 */
function mcas_private_storage_dir(): string
{
    $path = rtrim(MCAS_STORAGE_PATH, DIRECTORY_SEPARATOR);

    if (!is_dir($path) && !mkdir($path, 0750, true) && !is_dir($path)) {
        throw new RuntimeException('非公開ファイル保存先を作成できません。');
    }

    $realPath = realpath($path);
    if ($realPath === false) {
        throw new RuntimeException('非公開ファイル保存先を確認できません。');
    }

    $documentRoot = $_SERVER['DOCUMENT_ROOT'] ?? '';
    $realDocumentRoot = $documentRoot !== '' ? realpath($documentRoot) : false;

    if ($realDocumentRoot !== false) {
        $publicPrefix = rtrim($realDocumentRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;

        if (
            $realPath === $realDocumentRoot ||
            str_starts_with($realPath . DIRECTORY_SEPARATOR, $publicPrefix)
        ) {
            throw new RuntimeException(
                '保存先が公開フォルダ内です。public_htmlの外に設定してください。'
            );
        }
    }

    return $realPath;
}

/**
 * 現在の利用者が所有する項目を取得します。
 */
function mcas_owned_file_item(int $itemId): ?array
{
    $stmt = mcas_db()->prepare(
        'SELECT id, tenant_id, owner_user_id, parent_id, item_type,
                display_name, storage_key, mime_type, file_size
         FROM mcas_storage_items
         WHERE id = :id AND owner_user_id = :owner_id
         LIMIT 1'
    );

    $stmt->execute([
        ':id' => $itemId,
        ':owner_id' => (int)$_SESSION['user_id'],
    ]);

    $item = $stmt->fetch();
    return $item ?: null;
}

/**
 * 指定フォルダが現在の利用者のものか確認します。
 */
function mcas_validate_parent(?int $parentId): void
{
    if ($parentId === null) {
        return;
    }

    $parent = mcas_owned_file_item($parentId);

    if (!$parent || $parent['item_type'] !== 'folder') {
        throw new RuntimeException('保存先フォルダが見つかりません。');
    }
}

/**
 * 保存キーから実ファイルのパスを組み立てます。
 */
function mcas_storage_file_path(string $storageKey): string
{
    if (!preg_match('/^[a-f0-9]{64}$/', $storageKey)) {
        throw new RuntimeException('ファイル情報が正しくありません。');
    }

    return mcas_private_storage_dir() . DIRECTORY_SEPARATOR . $storageKey;
}

/**
 * 表示・保存に使うファイル名を簡易的に整えます。
 */
function mcas_clean_display_name(string $name): string
{
    $name = str_replace(["\0", '/', '\\'], '', $name);
    $name = trim($name);

    if ($name === '' || $name === '.' || $name === '..') {
        throw new RuntimeException('ファイル名を入力してください。');
    }

    if (mb_strlen($name) > 255) {
        throw new RuntimeException('ファイル名は255文字以内にしてください。');
    }

    return $name;
}