<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

/**
 * システム管理者、または自分の団体の管理者かを確認します。
 */
function mcas_require_link_admin(): void
{
    mcas_require_login();

    $userId = (int)($_SESSION['user_id'] ?? 0);
    $role = (string)($_SESSION['role'] ?? '');
    $tenantId = $_SESSION['tenant_id'] ?? null;

    if ($role === 'system_admin') {
        return;
    }

    if ($userId < 1 || $tenantId === null) {
        http_response_code(403);
        exit('サイトリンクを管理する権限がありません。');
    }

    $stmt = mcas_db()->prepare(
        'SELECT 1
         FROM organization_admins
         WHERE organization_id = :organization_id
           AND user_id = :user_id
         LIMIT 1'
    );
    $stmt->execute([
        ':organization_id' => (int)$tenantId,
        ':user_id' => $userId,
    ]);

    if (!$stmt->fetchColumn()) {
        http_response_code(403);
        exit('サイトリンクを管理する権限がありません。');
    }
}

/**
 * URLはHTTPまたはHTTPSに限定します。
 */
function mcas_validate_site_url(string $url): string
{
    $url = trim($url);

    if ($url === '' || strlen($url) > 2048) {
        throw new RuntimeException('URLを入力してください（2048文字以内）。');
    }

    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        throw new RuntimeException('有効なURLを入力してください。');
    }

    $parts = parse_url($url);
    $scheme = strtolower((string)($parts['scheme'] ?? ''));

    if (
        !in_array($scheme, ['http', 'https'], true) ||
        empty($parts['host']) ||
        isset($parts['user']) ||
        isset($parts['pass'])
    ) {
        throw new RuntimeException('URLは http:// または https:// で入力してください。');
    }

    return $url;
}

/**
 * JPEG画像を検証して、指定された固定名で安全に保存します。
 */
function mcas_replace_public_jpeg(string $targetName, array $upload): void
{
    $allowedNames = [
        'app-icon.jpg',
        'product-devices.jpg',
        'feature-overview.jpg',
    ];

    if (!in_array($targetName, $allowedNames, true)) {
        throw new RuntimeException('指定された画像名は使用できません。');
    }

    if (
        !isset($upload['error'], $upload['tmp_name'], $upload['size']) ||
        (int)$upload['error'] !== UPLOAD_ERR_OK ||
        !is_uploaded_file((string)$upload['tmp_name'])
    ) {
        throw new RuntimeException('画像のアップロードに失敗しました。');
    }

    if ((int)$upload['size'] < 1 || (int)$upload['size'] > 5 * 1024 * 1024) {
        throw new RuntimeException('画像は5MB以下にしてください。');
    }

    $imageInfo = @getimagesize((string)$upload['tmp_name']);

    if (
        !$imageInfo ||
        ($imageInfo[2] ?? null) !== IMAGETYPE_JPEG ||
        (int)$imageInfo[0] < 1 ||
        (int)$imageInfo[1] < 1 ||
        (int)$imageInfo[0] > 5000 ||
        (int)$imageInfo[1] > 5000
    ) {
        throw new RuntimeException('5000×5000ピクセル以内のJPEG画像を選択してください。');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    if ($finfo->file((string)$upload['tmp_name']) !== 'image/jpeg') {
        throw new RuntimeException('JPEG画像として確認できませんでした。');
    }

    if (!function_exists('imagecreatefromjpeg') || !function_exists('imagejpeg')) {
        throw new RuntimeException('画像処理機能がサーバーで利用できません。');
    }

    $image = @imagecreatefromjpeg((string)$upload['tmp_name']);

    if ($image === false) {
        throw new RuntimeException('画像を読み込めませんでした。');
    }

    $imagesDir = dirname(__DIR__) . '/public_html/assets/images';

    if (!is_dir($imagesDir) && !mkdir($imagesDir, 0755, true) && !is_dir($imagesDir)) {
        imagedestroy($image);
        throw new RuntimeException('画像フォルダを作成できません。');
    }

    $targetPath = $imagesDir . '/' . $targetName;
    $temporaryPath = $targetPath . '.tmp-' . bin2hex(random_bytes(8));

    $saved = imagejpeg($image, $temporaryPath, 90);
    imagedestroy($image);

    if (!$saved) {
        @unlink($temporaryPath);
        throw new RuntimeException('画像を保存できませんでした。');
    }

    chmod($temporaryPath, 0644);

    if (!rename($temporaryPath, $targetPath)) {
        @unlink($temporaryPath);
        throw new RuntimeException('画像を差し替えられませんでした。');
    }
}