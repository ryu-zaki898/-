<?php
declare(strict_types=1);

return [
    'public_key' => '<生成された公開鍵>',
    'private_key' => '<生成された秘密鍵>',
];