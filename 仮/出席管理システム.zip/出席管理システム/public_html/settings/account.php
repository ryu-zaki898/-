<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

mcas_require_login();

$pdo = mcas_db();
$userId = (int)$_SESSION['user_id'];
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        mcas_verify_csrf();

        $displayName = trim((string)($_POST['display_name'] ?? ''));
        $currentPassword = (string)($_POST['current_password'] ?? '');
        $newPassword = (string)($_POST['new_password'] ?? '');
        $confirmPassword = (string)($_POST['confirm_password'] ?? '');

        if ($displayName === '' || mb_strlen($displayName) > 100) {
            throw new RuntimeException('表示名を入力してください（100文字以内）。');
        }

        $stmt = $pdo->prepare(
            'SELECT password_hash FROM users WHERE id = :id LIMIT 1'
        );
        $stmt->execute([':id' => $userId]);
        $user = $stmt->fetch();

        if (!$user) {
            throw new RuntimeException('アカウントが見つかりません。');
        }

        if ($newPassword !== '') {
            if (!password_verify($currentPassword, (string)$user['password_hash'])) {
                throw new RuntimeException('現在のパスワードが違います。');
            }
            if (strlen($newPassword) < 12) {
                throw new RuntimeException('新しいパスワードは12文字以上にしてください。');
            }
            if ($newPassword !== $confirmPassword) {
                throw new RuntimeException('新しいパスワードが一致しません。');
            }

            $stmt = $pdo->prepare(
                'UPDATE users
                 SET display_name = :display_name,
                     password_hash = :password_hash
                 WHERE id = :id'
            );
            $stmt->execute([
                ':display_name' => $displayName,
                ':password_hash' => password_hash($newPassword, PASSWORD_DEFAULT),
                ':id' => $userId,
            ]);
        } else {
            $stmt = $pdo->prepare(
                'UPDATE users SET display_name = :display_name WHERE id = :id'
            );
            $stmt->execute([
                ':display_name' => $displayName,
                ':id' => $userId,
            ]);
        }

        $_SESSION['display_name'] = $displayName;
        $message = 'アカウント情報を更新しました。';
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

$stmt = $pdo->prepare(
    'SELECT login_id, email, display_name FROM users WHERE id = :id LIMIT 1'
);
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch();

if (!$user) {
    http_response_code(404);
    exit('アカウントが見つかりません。');
}
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>アカウント設定 - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="mcas-container">
    <h1>アカウント設定</h1>

    <?php if ($message !== ''): ?>
        <p><?= mcas_e($message) ?></p>
    <?php endif; ?>
    <?php if ($error !== ''): ?>
        <p role="alert"><?= mcas_e($error) ?></p>
    <?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token"
               value="<?= mcas_e(mcas_csrf_token()) ?>">

        <p>ログインID：<?= mcas_e($user['login_id']) ?></p>
        <p>メールアドレス：<?= mcas_e($user['email']) ?></p>

        <label>
            表示名
            <input type="text" name="display_name" maxlength="100"
                   value="<?= mcas_e($user['display_name']) ?>" required>
        </label>

        <h2>パスワード変更（変更する場合のみ入力）</h2>
        <label>
            現在のパスワード
            <input type="password" name="current_password" autocomplete="current-password">
        </label>
        <label>
            新しいパスワード（12文字以上）
            <input type="password" name="new_password" minlength="12"
                   autocomplete="new-password">
        </label>
        <label>
            新しいパスワード（確認）
            <input type="password" name="confirm_password" minlength="12"
                   autocomplete="new-password">
        </label>

        <button type="submit">保存</button>
    </form>
</main>
</body>
</html>