<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

mcas_require_login();

$tenantId = $_SESSION['tenant_id'] ?? null;

if ($tenantId === null) {
    $stmt = mcas_db()->query(
        'SELECT room_name, provider, join_url, expires_at
         FROM mcas_meeting_rooms
         WHERE tenant_id IS NULL
           AND is_active = 1
           AND (expires_at IS NULL OR expires_at > NOW())
         ORDER BY created_at DESC'
    );
    $rooms = $stmt->fetchAll();
} else {
    $stmt = mcas_db()->prepare(
        'SELECT room_name, provider, join_url, expires_at
         FROM mcas_meeting_rooms
         WHERE is_active = 1
           AND (tenant_id IS NULL OR tenant_id = :tenant_id)
           AND (expires_at IS NULL OR expires_at > NOW())
         ORDER BY created_at DESC'
    );
    $stmt->execute([':tenant_id' => (int)$tenantId]);
    $rooms = $stmt->fetchAll();
}
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>会議リンク - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="mcas-container">
    <h1>会議リンク</h1>
    <p>参加する会議を選んでください。リンク先は外部の会議サービスです。</p>

    <?php if (!$rooms): ?>
        <p>現在、利用できる会議リンクはありません。</p>
    <?php endif; ?>

    <div class="mcas-card-grid">
        <?php foreach ($rooms as $room): ?>
            <article class="mcas-card">
                <h2><?= mcas_e($room['room_name']) ?></h2>
                <p>サービス：<?= mcas_e($room['provider']) ?></p>
                <?php if ($room['expires_at'] !== null): ?>
                    <p>有効期限：<?= mcas_e($room['expires_at']) ?></p>
                <?php endif; ?>
                <a href="<?= mcas_e($room['join_url']) ?>"
                   target="_blank" rel="noopener noreferrer">
                    会議に参加
                </a>
            </article>
        <?php endforeach; ?>
    </div>

    <?php if (in_array($_SESSION['role'] ?? '', ['system_admin', 'organization_admin'], true)): ?>
        <p><a href="/meet/admin.php">会議リンクを管理</a></p>
    <?php endif; ?>
</main>
</body>
</html>