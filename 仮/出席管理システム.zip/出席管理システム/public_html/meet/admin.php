<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/meeting_manager.php';

mcas_require_meeting_admin();

$pdo = mcas_db();
$userId = (int)$_SESSION['user_id'];
$isSystemAdmin = (($_SESSION['role'] ?? '') === 'system_admin');
$tenantId = isset($_SESSION['tenant_id']) ? (int)$_SESSION['tenant_id'] : null;

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        mcas_verify_csrf();

        $action = (string)($_POST['action'] ?? '');

        if ($action === 'create') {
            $roomName = trim((string)($_POST['room_name'] ?? ''));
            $provider = trim((string)($_POST['provider'] ?? 'external'));
            $joinUrl = mcas_validate_meeting_url((string)($_POST['join_url'] ?? ''));
            $expiresInput = trim((string)($_POST['expires_at'] ?? ''));
            $expiresAt = null;

            if ($roomName === '' || mb_strlen($roomName) > 150) {
                throw new RuntimeException('会議名を入力してください（150文字以内）。');
            }

            if (!preg_match('/^[A-Za-z0-9_-]{2,50}$/', $provider)) {
                throw new RuntimeException('サービス名は半角英数字で入力してください。');
            }

            if ($expiresInput !== '') {
                $date = DateTimeImmutable::createFromFormat('Y-m-d\TH:i', $expiresInput);
                if (!$date || $date <= new DateTimeImmutable()) {
                    throw new RuntimeException('終了日時は未来の日時にしてください。');
                }
                $expiresAt = $date->format('Y-m-d H:i:s');
            }

            $stmt = $pdo->prepare(
                'INSERT INTO mcas_meeting_rooms
                    (tenant_id, created_by_user_id, room_name, provider,
                     join_url, is_active, expires_at)
                 VALUES
                    (:tenant_id, :user_id, :room_name, :provider,
                     :join_url, 1, :expires_at)'
            );
            $stmt->execute([
                ':tenant_id' => $isSystemAdmin ? null : $tenantId,
                ':user_id' => $userId,
                ':room_name' => $roomName,
                ':provider' => $provider,
                ':join_url' => $joinUrl,
                ':expires_at' => $expiresAt,
            ]);

            $message = '会議リンクを登録しました。';
        } elseif ($action === 'toggle') {
            $roomId = filter_input(INPUT_POST, 'room_id', FILTER_VALIDATE_INT);

            if (!$roomId || $roomId < 1) {
                throw new RuntimeException('会議リンクを確認できません。');
            }

            if ($isSystemAdmin) {
                $stmt = $pdo->prepare(
                    'UPDATE mcas_meeting_rooms
                     SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END
                     WHERE id = :id'
                );
                $stmt->execute([':id' => $roomId]);
            } else {
                $stmt = $pdo->prepare(
                    'UPDATE mcas_meeting_rooms
                     SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END
                     WHERE id = :id AND tenant_id = :tenant_id'
                );
                $stmt->execute([
                    ':id' => $roomId,
                    ':tenant_id' => $tenantId,
                ]);
            }

            if ($stmt->rowCount() < 1) {
                throw new RuntimeException('会議リンクが見つからないか、変更できません。');
            }

            $message = '会議リンクの公開状態を変更しました。';
        } else {
            throw new RuntimeException('操作を確認できません。');
        }
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

if ($isSystemAdmin) {
    $rooms = $pdo->query(
        'SELECT id, tenant_id, room_name, provider, join_url, is_active,
                expires_at, created_at
         FROM mcas_meeting_rooms
         ORDER BY id DESC'
    )->fetchAll();
} else {
    $stmt = $pdo->prepare(
        'SELECT id, tenant_id, room_name, provider, join_url, is_active,
                expires_at, created_at
         FROM mcas_meeting_rooms
         WHERE tenant_id = :tenant_id
         ORDER BY id DESC'
    );
    $stmt->execute([':tenant_id' => $tenantId]);
    $rooms = $stmt->fetchAll();
}
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>会議リンク管理 - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="mcas-container">
    <h1>会議リンク管理</h1>
    <p>会議サービス側で作成した参加URLを登録してください。</p>

    <?php if ($message !== ''): ?><p><?= mcas_e($message) ?></p><?php endif; ?>
    <?php if ($error !== ''): ?><p role="alert"><?= mcas_e($error) ?></p><?php endif; ?>

    <section class="mcas-card">
        <h2>会議リンクを登録</h2>
        <form method="post">
            <input type="hidden" name="csrf_token"
                   value="<?= mcas_e(mcas_csrf_token()) ?>">

            <label>会議名
                <input type="text" name="room_name" maxlength="150" required>
            </label>

            <label>サービス名（例：zoom、meet、teams）
                <input type="text" name="provider" value="external"
                       pattern="[A-Za-z0-9_-]{2,50}" maxlength="50" required>
            </label>

            <label>参加URL
                <input type="url" name="join_url" maxlength="2048" required>
            </label>

            <label>有効期限（任意）
                <input type="datetime-local" name="expires_at">
            </label>

            <button type="submit" name="action" value="create">登録する</button>
        </form>
    </section>

    <section class="mcas-section">
        <h2>登録済み会議リンク</h2>

        <?php if (!$rooms): ?>
            <p>会議リンクはまだありません。</p>
        <?php endif; ?>

        <?php foreach ($rooms as $room): ?>
            <article class="mcas-card" style="margin-bottom: 14px">
                <h3><?= mcas_e($room['room_name']) ?></h3>
                <p>サービス：<?= mcas_e($room['provider']) ?></p>
                <p>状態：<?= (int)$room['is_active'] === 1 ? '公開中' : '停止中' ?></p>
                <p>有効期限：<?= mcas_e($room['expires_at'] ?? 'なし') ?></p>

                <form method="post">
                    <input type="hidden" name="csrf_token"
                           value="<?= mcas_e(mcas_csrf_token()) ?>">
                    <input type="hidden" name="room_id" value="<?= (int)$room['id'] ?>">
                    <button type="submit" name="action" value="toggle">
                        <?= (int)$room['is_active'] === 1 ? '停止する' : '再公開する' ?>
                    </button>
                </form>
            </article>
        <?php endforeach; ?>
    </section>
</main>
</body>
</html>