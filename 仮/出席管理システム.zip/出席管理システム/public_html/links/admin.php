<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/link_manager.php';

mcas_require_link_admin();

$pdo = mcas_db();
$userId = (int)$_SESSION['user_id'];
$tenantId = isset($_SESSION['tenant_id'])
    ? (int)$_SESSION['tenant_id']
    : null;

$message = '';
$error = '';

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        mcas_verify_csrf();

        $action = (string)($_POST['action'] ?? '');

        if ($action === 'add_link') {
            $name = trim((string)($_POST['name'] ?? ''));
            $url = mcas_validate_site_url((string)($_POST['url'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));

            if ($name === '' || mb_strlen($name) > 150) {
                throw new RuntimeException('リンク名を入力してください（150文字以内）。');
            }

            if (mb_strlen($description) > 2000) {
                throw new RuntimeException('説明は2000文字以内にしてください。');
            }

            $stmt = $pdo->prepare(
                'INSERT INTO mcas_site_links
                    (tenant_id, name, url, description, sort_order,
                     is_active, created_by_user_id)
                 VALUES
                    (:tenant_id, :name, :url, :description, 0, 1, :user_id)'
            );
            $stmt->execute([
                ':tenant_id' => $tenantId,
                ':name' => $name,
                ':url' => $url,
                ':description' => $description !== '' ? $description : null,
                ':user_id' => $userId,
            ]);

            $message = 'サイトリンクを登録しました。';
        } elseif ($action === 'toggle_link') {
            $linkId = filter_input(INPUT_POST, 'link_id', FILTER_VALIDATE_INT);
            if (!$linkId || $linkId < 1) {
                throw new RuntimeException('リンクを確認できません。');
            }

            $stmt = $pdo->prepare(
                'UPDATE mcas_site_links
                 SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END
                 WHERE id = :id AND tenant_id <=> :tenant_id'
            );
            $stmt->execute([
                ':id' => (int)$linkId,
                ':tenant_id' => $tenantId,
            ]);

            if ($stmt->rowCount() < 1) {
                throw new RuntimeException('対象リンクが見つからないか、変更できません。');
            }

            $message = 'リンクの公開状態を変更しました。';
        } elseif ($action === 'delete_link') {
            $linkId = filter_input(INPUT_POST, 'link_id', FILTER_VALIDATE_INT);
            if (!$linkId || $linkId < 1) {
                throw new RuntimeException('リンクを確認できません。');
            }

            $stmt = $pdo->prepare(
                'DELETE FROM mcas_site_links
                 WHERE id = :id AND tenant_id <=> :tenant_id'
            );
            $stmt->execute([
                ':id' => (int)$linkId,
                ':tenant_id' => $tenantId,
            ]);

            if ($stmt->rowCount() < 1) {
                throw new RuntimeException('対象リンクが見つからないか、削除できません。');
            }

            $message = 'サイトリンクを削除しました。';
        } elseif ($action === 'replace_image') {
            $imageName = (string)($_POST['image_name'] ?? '');
            mcas_replace_public_jpeg(
                $imageName,
                $_FILES['image'] ?? []
            );

            $message = '画像を差し替えました。';
        } else {
            throw new RuntimeException('操作を確認できません。');
        }
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}

$stmt = $pdo->prepare(
    'SELECT id, name, url, description, is_active, created_at
     FROM mcas_site_links
     WHERE tenant_id <=> :tenant_id
     ORDER BY sort_order ASC, id DESC'
);
$stmt->execute([':tenant_id' => $tenantId]);
$links = $stmt->fetchAll();

$images = [
    'app-icon.jpg' => 'アプリアイコン',
    'product-devices.jpg' => '携帯・パソコンの利用イメージ',
    'feature-overview.jpg' => '機能紹介画像',
];
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>リンク・画像管理 - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
    <style>
        .admin-panel { margin-top: 24px; padding: 20px; background: #fff;
            border: 1px solid #dce6f1; border-radius: 18px; }
        .admin-form { display: grid; gap: 12px; max-width: 700px; }
        .admin-form label { display: grid; gap: 5px; font-weight: 700; }
        .admin-form input, .admin-form textarea, .admin-form select {
            width: 100%; padding: 10px; border: 1px solid #cbd7e5;
            border-radius: 9px; font: inherit;
        }
        .admin-form button, .admin-row button {
            min-height: 42px; padding: 8px 14px; border: 0;
            border-radius: 9px; color: #fff; background: #0759c7;
            font: inherit; font-weight: 700; cursor: pointer;
        }
        .admin-row { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; }
        .admin-row form { display: inline; }
        .admin-row .danger { background: #9b2c2c; }
        .admin-item { padding: 16px 0; border-bottom: 1px solid #e5edf5; }
        .admin-message { padding: 12px 16px; background: #edf4fb; border-radius: 10px; }
        .admin-error { color: #8b1e1e; background: #fff0f0; }
    </style>
</head>
<body>
<header class="mcas-header">
    <div class="mcas-header-inner">
        <a class="mcas-brand" href="/product.php">
            <span class="mcas-brand-name"><?= mcas_e(MCAS_APP_NAME) ?></span>
        </a>
        <nav class="mcas-nav" aria-label="メインメニュー">
            <a href="/links/">登録リンクを見る</a>
            <a href="/files/">ファイル管理</a>
        </nav>
    </div>
</header>

<main class="mcas-container">
    <h1>リンク・画像管理</h1>

    <?php if ($message !== ''): ?>
        <p class="admin-message"><?= mcas_e($message) ?></p>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <p class="admin-message admin-error" role="alert"><?= mcas_e($error) ?></p>
    <?php endif; ?>

    <section class="admin-panel">
        <h2>サイトリンクを追加</h2>
        <form class="admin-form" method="post">
            <input type="hidden" name="csrf_token"
                   value="<?= mcas_e(mcas_csrf_token()) ?>">
            <label>
                リンク名
                <input type="text" name="name" maxlength="150" required>
            </label>
            <label>
                URL（http:// または https://）
                <input type="url" name="url" maxlength="2048" required>
            </label>
            <label>
                説明（任意）
                <textarea name="description" maxlength="2000" rows="3"></textarea>
            </label>
            <button type="submit" name="action" value="add_link">登録</button>
        </form>
    </section>

    <section class="admin-panel">
        <h2>登録済みリンク</h2>

        <?php if (!$links): ?>
            <p>リンクはまだ登録されていません。</p>
        <?php endif; ?>

        <?php foreach ($links as $link): ?>
            <article class="admin-item">
                <h3><?= mcas_e($link['name']) ?></h3>
                <p><?= mcas_e($link['url']) ?></p>
                <?php if (!empty($link['description'])): ?>
                    <p><?= nl2br(mcas_e($link['description'])) ?></p>
                <?php endif; ?>
                <p>状態：<?= (int)$link['is_active'] === 1 ? '公開中' : '停止中' ?></p>

                <div class="admin-row">
                    <form method="post">
                        <input type="hidden" name="csrf_token"
                               value="<?= mcas_e(mcas_csrf_token()) ?>">
                        <input type="hidden" name="link_id" value="<?= (int)$link['id'] ?>">
                        <button type="submit" name="action" value="toggle_link">
                            <?= (int)$link['is_active'] === 1 ? '停止する' : '公開する' ?>
                        </button>
                    </form>

                    <form method="post"
                          onsubmit="return confirm('このリンクを削除しますか？');">
                        <input type="hidden" name="csrf_token"
                               value="<?= mcas_e(mcas_csrf_token()) ?>">
                        <input type="hidden" name="link_id" value="<?= (int)$link['id'] ?>">
                        <button class="danger" type="submit" name="action"
                                value="delete_link">削除</button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </section>

    <section class="admin-panel">
        <h2>紹介ページの画像を差し替え</h2>
        <p>JPEG画像（5MB以下）を選んでください。選んだ固定名で現在の画像を置き換えます。</p>

        <?php foreach ($images as $filename => $label): ?>
            <form class="admin-form" method="post" enctype="multipart/form-data"
                  style="margin-bottom: 24px">
                <input type="hidden" name="csrf_token"
                       value="<?= mcas_e(mcas_csrf_token()) ?>">
                <input type="hidden" name="image_name"
                       value="<?= mcas_e($filename) ?>">

                <label>
                    <?= mcas_e($label) ?>（<?= mcas_e($filename) ?>）
                    <input type="file" name="image" accept="image/jpeg" required>
                </label>
                <button type="submit" name="action" value="replace_image">
                    この画像を差し替える
                </button>
            </form>
        <?php endforeach; ?>
    </section>
</main>
</body>
</html>