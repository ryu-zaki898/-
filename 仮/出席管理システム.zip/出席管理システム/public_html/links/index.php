<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

mcas_require_login();

$tenantId = $_SESSION['tenant_id'] ?? null;

if ($tenantId === null) {
    $stmt = mcas_db()->query(
        'SELECT id, name, url, description
         FROM mcas_site_links
         WHERE tenant_id IS NULL AND is_active = 1
         ORDER BY sort_order ASC, id DESC'
    );
    $links = $stmt->fetchAll();
} else {
    $stmt = mcas_db()->prepare(
        'SELECT id, name, url, description
         FROM mcas_site_links
         WHERE is_active = 1
           AND (tenant_id IS NULL OR tenant_id = :tenant_id)
         ORDER BY sort_order ASC, id DESC'
    );
    $stmt->execute([':tenant_id' => (int)$tenantId]);
    $links = $stmt->fetchAll();
}

$selectedId = isset($_GET['id']) && ctype_digit((string)$_GET['id'])
    ? (int)$_GET['id']
    : null;

$selectedLink = null;
foreach ($links as $link) {
    if ((int)$link['id'] === $selectedId) {
        $selectedLink = $link;
        break;
    }
}
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>登録サイトリンク - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
    <style>
        .link-list { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px; }
        .link-card { padding: 18px; background: #fff; border: 1px solid #dce6f1;
            border-radius: 16px; }
        .link-card h2 { margin: 0 0 8px; font-size: 1.1rem; }
        .link-card p { color: #64748b; }
        .link-viewer { width: 100%; height: min(72vh, 760px); border: 1px solid #dce6f1;
            border-radius: 16px; background: #fff; }
        @media (max-width: 650px) {
            .link-list { grid-template-columns: 1fr; }
            .link-viewer { height: 65vh; }
        }
    </style>
</head>
<body>
<header class="mcas-header">
    <div class="mcas-header-inner">
        <a class="mcas-brand" href="/product.php">
            <span class="mcas-brand-name"><?= mcas_e(MCAS_APP_NAME) ?></span>
        </a>
        <nav class="mcas-nav" aria-label="メインメニュー">
            <a href="/files/">ファイル管理</a>
            <a href="/links/admin.php">リンク管理</a>
        </nav>
    </div>
</header>

<main class="mcas-container">
    <h1>登録サイトリンク</h1>

    <?php if (!$links): ?>
        <p>現在、表示できるリンクはありません。</p>
    <?php else: ?>
        <div class="link-list">
            <?php foreach ($links as $link): ?>
                <article class="link-card">
                    <h2>
                        <a href="/links/?id=<?= (int)$link['id'] ?>">
                            <?= mcas_e($link['name']) ?>
                        </a>
                    </h2>

                    <?php if (!empty($link['description'])): ?>
                        <p><?= nl2br(mcas_e($link['description'])) ?></p>
                    <?php endif; ?>

                    <a href="<?= mcas_e($link['url']) ?>"
                       target="_blank" rel="noopener noreferrer">
                        別タブで開く
                    </a>
                </article>
            <?php endforeach; ?>
        </div>

        <?php if ($selectedLink): ?>
            <section class="mcas-section">
                <h2><?= mcas_e($selectedLink['name']) ?></h2>
                <p>
                    埋め込み表示に対応していないサイトでは、下の枠が空白になることがあります。
                    その場合は「別タブで開く」を使ってください。
                </p>
                <p>
                    <a href="<?= mcas_e($selectedLink['url']) ?>"
                       target="_blank" rel="noopener noreferrer">
                        <?= mcas_e($selectedLink['name']) ?>を別タブで開く
                    </a>
                </p>
                <iframe
                    class="link-viewer"
                    src="<?= mcas_e($selectedLink['url']) ?>"
                    title="<?= mcas_e($selectedLink['name']) ?>"
                    loading="lazy"
                    referrerpolicy="strict-origin-when-cross-origin"
                    sandbox="allow-forms allow-scripts allow-popups">
                </iframe>
            </section>
        <?php endif; ?>
    <?php endif; ?>
</main>
</body>
</html>