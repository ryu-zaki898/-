<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/app/bootstrap.php';

$iconFile = __DIR__ . '/assets/images/app-icon.jpg';
$overviewFile = __DIR__ . '/assets/images/feature-overview.jpg';

$features = [
    [
        'title' => '出席管理',
        'description' => '団体活動の出席情報を管理するための機能です。',
        'status' => '既存機能',
    ],
    [
        'title' => 'ファイル・フォルダ管理',
        'description' => 'ファイルのアップロード、ダウンロード、フォルダ作成、テキスト編集を行う機能です。',
        'status' => '追加予定',
    ],
    [
        'title' => 'アカウント・権限管理',
        'description' => 'システム管理者、団体管理者、一般利用者などの権限を分けて管理する機能です。',
        'status' => '追加予定',
    ],
    [
        'title' => 'サイトリンク',
        'description' => '管理者が登録したサイトを一覧表示し、開けるようにする機能です。',
        'status' => '追加予定',
    ],
    [
        'title' => '写真・動画',
        'description' => '対応する端末のカメラやマイクを使って撮影・保存する機能です。',
        'status' => '追加予定',
    ],
    [
        'title' => '通知',
        'description' => 'メールやWeb Pushを使った通知機能です。Push通知には鍵とサーバー側の設定が必要です。',
        'status' => '追加予定',
    ],
    [
        'title' => 'ビデオ会議',
        'description' => '会議サービスとの連携を前提とした機能です。外部サービスの設定が別途必要です。',
        'status' => '連携予定',
    ],
    [
        'title' => '製品紹介・機能紹介',
        'description' => '画像や説明を載せ、アプリの概要と機能を案内するページです。',
        'status' => '今回作成中',
    ],
];
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
          content="MyControlAssociationSystemの主な機能と実装状況を紹介します。">
    <title>機能紹介 - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header class="mcas-header">
    <div class="mcas-header-inner">
        <a class="mcas-brand" href="/product.php">
            <?php if (is_file($iconFile)): ?>
                <img src="/assets/images/app-icon.jpg"
                     alt="<?= mcas_e(MCAS_APP_NAME) ?> アプリアイコン">
            <?php endif; ?>
            <span class="mcas-brand-name"><?= mcas_e(MCAS_APP_NAME) ?></span>
        </a>

        <nav class="mcas-nav" aria-label="メインメニュー">
            <a href="/product.php">製品紹介</a>
            <a href="/features.php" aria-current="page">機能紹介</a>
            <a href="/login.php">ログイン</a>
        </nav>
    </div>
</header>

<main class="mcas-container">
    <section class="mcas-section" style="margin-top: 0">
        <div class="mcas-section-heading">
            <span class="mcas-eyebrow" style="color: #0759c7">Features</span>
            <h1>機能紹介</h1>
            <p>
                現在の機能と、これから追加する機能を区別して紹介します。
            </p>
        </div>

        <?php if (is_file($overviewFile)): ?>
            <div class="mcas-feature-banner">
                <img src="/assets/images/feature-overview.jpg"
                     alt="団体の情報共有と出席管理を表す機能イメージ">
                <div class="mcas-feature-banner-copy">
                    <h2>団体の運営を支える機能を、ひとつずつ</h2>
                    <p>
                        出席管理を土台に、ファイル管理、情報共有、通知などを
                        段階的に追加する計画です。
                    </p>
                </div>
            </div>
        <?php else: ?>
            <div class="mcas-feature-banner">
                <div class="mcas-feature-banner-copy">
                    <h2>機能イメージ画像を差し替えできます</h2>
                    <p>
                        横長画像を
                        <code>assets/images/feature-overview.jpg</code>
                        の名前で置くと、ここに表示されます。
                    </p>
                </div>
            </div>
        <?php endif; ?>
    </section>

    <section class="mcas-section">
        <div class="mcas-card-grid">
            <?php foreach ($features as $feature): ?>
                <article class="mcas-card">
                    <h2><?= mcas_e($feature['title']) ?></h2>
                    <p><?= mcas_e($feature['description']) ?></p>
                    <span class="mcas-status"><?= mcas_e($feature['status']) ?></span>
                </article>
            <?php endforeach; ?>
        </div>

        <div class="mcas-note">
            「追加予定」「連携予定」と表示している機能は、実装と動作確認が完了するまで利用できません。
            特にPush通知はVAPID鍵に加えて送信処理の設定、ビデオ会議は外部サービスとの連携が必要です。
        </div>
    </section>
</main>

<footer class="mcas-footer">
    <div class="mcas-footer-inner">
        <span><?= mcas_e(MCAS_APP_NAME) ?></span>
        <a href="/product.php">製品紹介へ戻る</a>
    </div>
</footer>
</body>
</html>