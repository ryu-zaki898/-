"use strict";

self.addEventListener("push", (event) => {
    let data = {};

    try {
        data = event.data ? event.data.json() : {};
    } catch (_error) {
        data = {
            title: "MyControlAssociationSystem",
            body: event.data ? event.data.text() : ""
        };
    }

    const title = String(data.title || "MyControlAssociationSystem");
    const body = String(data.body || "");
    const targetUrl = String(data.url || "/notifications/");

    const options = {
        body,
        icon: "/assets/images/app-icon.jpg",
        badge: "/assets/images/app-icon.jpg",
        data: { url: targetUrl }
    };

    event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
    event.notification.close();

    const requested = event.notification.data?.url || "/notifications/";
    let target;

    try {
        target = new URL(requested, self.location.origin);
    } catch (_error) {
        target = new URL("/notifications/", self.location.origin);
    }

    // 通知から外部サイトへ誘導しないよう、同一オリジンだけ許可します。
    if (target.origin !== self.location.origin) {
        target = new URL("/notifications/", self.location.origin);
    }

    event.waitUntil(
        clients.matchAll({ type: "window", includeUncontrolled: true })
            .then((windowClients) => {
                for (const client of windowClients) {
                    if (new URL(client.url).origin === self.location.origin) {
                        client.navigate(target.href);
                        return client.focus();
                    }
                }
                return clients.openWindow(target.href);
            })
    );
});