<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/app/bootstrap.php';

$message = '';
$completed = false;

try {
    $pdo = mcas_db();

    $userCount = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    $setupDone = $pdo->prepare(
        "SELECT setting_value
         FROM mcas_settings
         WHERE setting_key = 'initial_admin_created'
         LIMIT 1"
    );
    $setupDone->execute();

    if ($userCount > 0 || $setupDone->fetchColumn() === '1') {
        $completed = true;
        $message = '初期管理者の登録は完了済みです。';
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$completed) {
        mcas_verify_csrf();

        $config = $GLOBALS['config'] ?? [];
        $expectedKey = (string)($config['setup_key'] ?? '');
        $submittedKey = (string)($_POST['setup_key'] ?? '');

        if (
            strlen($expectedKey) < 32 ||
            !hash_equals($expectedKey, $submittedKey)
        ) {
            throw new RuntimeException('初期設定キーが違います。');
        }

        $organizationName = trim((string)($_POST['organization_name'] ?? ''));
        $contactEmail = trim((string)($_POST['contact_email'] ?? ''));
        $loginId = trim((string)($_POST['login_id'] ?? ''));
        $displayName = trim((string)($_POST['display_name'] ?? ''));
        $password = (string)($_POST['password'] ?? '');

        if ($organizationName === '' || mb_strlen($organizationName) > 150) {
            throw new RuntimeException('団体名を入力してください（150文字以内）。');
        }

        if (!filter_var($contactEmail, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('有効なメールアドレスを入力してください。');
        }

        if (!preg_match('/^[A-Za-z0-9_.-]{4,100}$/', $loginId)) {
            throw new RuntimeException(
                'ログインIDは半角英数字と _ . - を使い、4〜100文字にしてください。'
            );
        }

        if ($displayName === '' || mb_strlen($displayName) > 100) {
            throw new RuntimeException('表示名を入力してください（100文字以内）。');
        }

        if (strlen($password) < 12) {
            throw new RuntimeException('パスワードは12文字以上にしてください。');
        }

        // 同時に複数回の初期登録が実行されるのを防ぎます。
        $lockResult = (int)$pdo->query(
            "SELECT GET_LOCK('mcas_initial_admin_setup', 10)"
        )->fetchColumn();

        if ($lockResult !== 1) {
            throw new RuntimeException('初期設定を開始できません。時間をおいて再度お試しください。');
        }

        try {
            $pdo->beginTransaction();

            $userCount = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();

            $checkDone = $pdo->prepare(
                "SELECT setting_value
                 FROM mcas_settings
                 WHERE setting_key = 'initial_admin_created'
                 LIMIT 1"
            );
            $checkDone->execute();

            if ($userCount > 0 || $checkDone->fetchColumn() === '1') {
                throw new RuntimeException('初期管理者はすでに登録されています。');
            }

            $stmt = $pdo->prepare(
                "INSERT INTO organizations (name, status, contact_email)
                 VALUES (:name, 'approved', :email)"
            );
            $stmt->execute([
                ':name' => $organizationName,
                ':email' => $contactEmail,
            ]);
            $organizationId = (int)$pdo->lastInsertId();

            $stmt = $pdo->prepare(
                "INSERT INTO users
                    (tenant_id, login_id, email, password_hash, display_name, role, is_active)
                 VALUES
                    (:tenant_id, :login_id, :email, :password_hash, :display_name, 'system_admin', 1)"
            );
            $stmt->execute([
                ':tenant_id' => $organizationId,
                ':login_id' => $loginId,
                ':email' => $contactEmail,
                ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
                ':display_name' => $displayName,
            ]);
            $userId = (int)$pdo->lastInsertId();

            $stmt = $pdo->prepare(
                'INSERT INTO organization_admins (organization_id, user_id)
                 VALUES (:organization_id, :user_id)'
            );
            $stmt->execute([
                ':organization_id' => $organizationId,
                ':user_id' => $userId,
            ]);

            $stmt = $pdo->prepare(
                "INSERT INTO mcas_settings (setting_key, setting_value)
                 VALUES ('initial_admin_created', '1')
                 ON DUPLICATE KEY UPDATE setting_value = '1'"
            );
            $stmt->execute();

            $pdo->commit();

            $completed = true;
            $message = '初期管理者を登録しました。ログインページからログインしてください。';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        } finally {
            $pdo->query("SELECT RELEASE_LOCK('mcas_initial_admin_setup')");
        }
    }
} catch (Throwable $e) {
    $message = $e->getMessage();
}

?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>初期管理者登録 - MyControlAssociationSystem</title>
</head>
<body>
<main>
    <h1>初期管理者登録</h1>

    <?php if ($message !== ''): ?>
        <p><?= mcas_e($message) ?></p>
    <?php endif; ?>

    <?php if (!$completed): ?>
        <form method="post" action="">
            <input type="hidden" name="csrf_token"
                   value="<?= mcas_e(mcas_csrf_token()) ?>">

            <label>
                初期設定キー
                <input type="password" name="setup_key" required autocomplete="off">
            </label>

            <label>
                団体名
                <input type="text" name="organization_name" maxlength="150" required>
            </label>

            <label>
                管理者メールアドレス
                <input type="email" name="contact_email" maxlength="254" required>
            </label>

            <label>
                ログインID
                <input type="text" name="login_id" minlength="4" maxlength="100"
                       pattern="[A-Za-z0-9_.-]+" required autocomplete="username">
            </label>

            <label>
                表示名
                <input type="text" name="display_name" maxlength="100" required>
            </label>

            <label>
                パスワード（12文字以上）
                <input type="password" name="password" minlength="12"
                       required autocomplete="new-password">
            </label>

            <button type="submit">管理者を登録</button>
        </form>
    <?php else: ?>
        <p><a href="/login.php">ログインページへ</a></p>
    <?php endif; ?>
</main>
</body>
</html>