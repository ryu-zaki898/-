<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/file_manager.php';

mcas_require_login();

$pdo = mcas_db();
$userId = (int)$_SESSION['user_id'];
$itemId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$item = $itemId ? mcas_owned_file_item((int)$itemId) : null;

if (!$item || $item['item_type'] !== 'file') {
    http_response_code(404);
    exit('共有するファイルが見つかりません。');
}

$message = '';
$error = '';
$createdUrl = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        mcas_verify_csrf();
        $action = (string)($_POST['action'] ?? '');

        if ($action === 'create') {
            $password = (string)($_POST['password'] ?? '');
            $expiresInput = trim((string)($_POST['expires_at'] ?? ''));
            $expiresAt = null;

            if ($password !== '' && strlen($password) < 8) {
                throw new RuntimeException('共有パスワードは8文字以上にしてください。');
            }

            if ($expiresInput !== '') {
                $date = DateTimeImmutable::createFromFormat('Y-m-d\TH:i', $expiresInput);
                if (!$date || $date <= new DateTimeImmutable()) {
                    throw new RuntimeException('有効期限は未来の日時を指定してください。');
                }
                $expiresAt = $date->format('Y-m-d H:i:s');
            }

            $token = bin2hex(random_bytes(32));
            $passwordHash = $password !== ''
                ? password_hash($password, PASSWORD_DEFAULT)
                : null;

            $stmt = $pdo->prepare(
                'INSERT INTO mcas_file_shares
                    (storage_item_id, created_by_user_id, token_hash,
                     permission, password_hash, expires_at, is_active)
                 VALUES
                    (:item_id, :user_id, :token_hash, :permission,
                     :password_hash, :expires_at, 1)'
            );
            $stmt->execute([
                ':item_id' => (int)$item['id'],
                ':user_id' => $userId,
                ':token_hash' => hash('sha256', $token),
                ':permission' => 'view',
                ':password_hash' => $passwordHash,
                ':expires_at' => $expiresAt,
            ]);

            $createdUrl = '/files/shared.php?t=' . rawurlencode($token);
            $message = '共有リンクを作成しました。このURLは必要な相手にだけ伝えてください。';
        } elseif ($action === 'deactivate') {
            $shareId = filter_input(INPUT_POST, 'share_id', FILTER_VALIDATE_INT);

            $stmt = $pdo->prepare(
                'UPDATE mcas_file_shares s
                 INNER JOIN mcas_storage_items f ON f.id = s.storage_item_id
                 SET s.is_active = 0
                 WHERE s.id = :share_id
                   AND f.owner_user_id = :owner_id
                   AND f.id = :item_id'
            );
            $stmt->execute([
                ':share_id' => (int)$shareId,
                ':owner_id' => $userId,
                ':item_id' => (int)$item['id'],
            ]);

            $message = '共有リンクを停止しました。';
        }
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

$stmt = $pdo->prepare(
    'SELECT id, expires_at, is_active, password_hash, created_at
     FROM mcas_file_shares
     WHERE storage_item_id = :item_id AND created_by_user_id = :user_id
     ORDER BY id DESC'
);
$stmt->execute([
    ':item_id' => (int)$item['id'],
    ':user_id' => $userId,
]);
$shares = $stmt->fetchAll();
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ファイル共有 - <?= mcas_e(MCAS_APP_NAME) ?></title>
</head>
<body>
<main>
    <h1>ファイル共有</h1>
    <p>ファイル：<?= mcas_e($item['display_name']) ?></p>

    <?php if ($message !== ''): ?><p><?= mcas_e($message) ?></p><?php endif; ?>
    <?php if ($error !== ''): ?><p role="alert"><?= mcas_e($error) ?></p><?php endif; ?>

    <?php if ($createdUrl !== ''): ?>
        <p>共有URL（この画面を閉じる前に控えてください）：</p>
        <p><textarea rows="3" cols="60" readonly><?= mcas_e($createdUrl) ?></textarea></p>
        <p>相手にはサイトのドメインを含むURLを伝えてください。</p>
    <?php endif; ?>

    <h2>新しい共有リンク</h2>
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= mcas_e(mcas_csrf_token()) ?>">
        <label>共有パスワード（任意、設定する場合は8文字以上）
            <input type="password" name="password" minlength="8" autocomplete="new-password">
        </label>
        <label>有効期限（任意）
            <input type="datetime-local" name="expires_at">
        </label>
        <button type="submit" name="action" value="create">共有リンクを作成</button>
    </form>

    <h2>作成済みリンク</h2>
    <?php if (!$shares): ?>
        <p>共有リンクはありません。</p>
    <?php endif; ?>

    <?php foreach ($shares as $share): ?>
        <article>
            <p>作成日時：<?= mcas_e($share['created_at']) ?></p>
            <p>有効期限：<?= mcas_e($share['expires_at'] ?? 'なし') ?></p>
            <p>パスワード：<?= $share['password_hash'] ? '設定あり' : 'なし' ?></p>
            <p>状態：<?= (int)$share['is_active'] === 1 ? '有効' : '停止済み' ?></p>
            <?php if ((int)$share['is_active'] === 1): ?>
                <form method="post">
                    <input type="hidden" name="csrf_token"
                           value="<?= mcas_e(mcas_csrf_token()) ?>">
                    <input type="hidden" name="share_id" value="<?= (int)$share['id'] ?>">
                    <button type="submit" name="action" value="deactivate">この共有を停止</button>
                </form>
            <?php endif; ?>
        </article>
    <?php endforeach; ?>

    <p><a href="/files/">ファイル管理へ戻る</a></p>
</main>
</body>
</html>