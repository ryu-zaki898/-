<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/file_manager.php';

mcas_require_login();

$pdo = mcas_db();
$userId = (int)$_SESSION['user_id'];
$message = '';
$error = '';

$parentId = isset($_GET['parent']) && ctype_digit((string)$_GET['parent'])
    ? (int)$_GET['parent']
    : null;

try {
    mcas_validate_parent($parentId);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        mcas_verify_csrf();

        $action = (string)($_POST['action'] ?? '');
        $postedParent = isset($_POST['parent_id']) &&
            ctype_digit((string)$_POST['parent_id'])
                ? (int)$_POST['parent_id']
                : null;

        mcas_validate_parent($postedParent);

        if ($action === 'create_folder') {
            $name = mcas_clean_display_name((string)($_POST['name'] ?? ''));

            $stmt = $pdo->prepare(
                "INSERT INTO mcas_storage_items
                    (tenant_id, owner_user_id, parent_id, item_type, display_name)
                 VALUES
                    (:tenant_id, :owner_id, :parent_id, 'folder', :display_name)"
            );
            $stmt->execute([
                ':tenant_id' => $_SESSION['tenant_id'] ?? null,
                ':owner_id' => $userId,
                ':parent_id' => $postedParent,
                ':display_name' => $name,
            ]);

            $message = 'フォルダを作成しました。';
            $parentId = $postedParent;
        } elseif ($action === 'create_text') {
            $name = mcas_clean_display_name((string)($_POST['name'] ?? ''));

            if (!preg_match('/\.(txt|md|csv)$/i', $name)) {
                $name .= '.txt';
            }

            $key = bin2hex(random_bytes(32));
            $path = mcas_storage_file_path($key);

            if (file_put_contents($path, '', LOCK_EX) === false) {
                throw new RuntimeException('テキストファイルを作成できません。');
            }
            chmod($path, 0640);

            try {
                $stmt = $pdo->prepare(
                    "INSERT INTO mcas_storage_items
                        (tenant_id, owner_user_id, parent_id, item_type,
                         display_name, storage_key, mime_type, file_size)
                     VALUES
                        (:tenant_id, :owner_id, :parent_id, 'file',
                         :display_name, :storage_key, 'text/plain', 0)"
                );
                $stmt->execute([
                    ':tenant_id' => $_SESSION['tenant_id'] ?? null,
                    ':owner_id' => $userId,
                    ':parent_id' => $postedParent,
                    ':display_name' => $name,
                    ':storage_key' => $key,
                ]);
            } catch (Throwable $e) {
                @unlink($path);
                throw $e;
            }

            $message = '空のテキストファイルを作成しました。';
            $parentId = $postedParent;
        } elseif ($action === 'save_text') {
            $itemId = filter_input(INPUT_POST, 'item_id', FILTER_VALIDATE_INT);
            $item = $itemId ? mcas_owned_file_item((int)$itemId) : null;

            if (
                !$item ||
                $item['item_type'] !== 'file' ||
                !preg_match('/\.(txt|md|csv)$/i', (string)$item['display_name'])
            ) {
                throw new RuntimeException('編集できるテキストファイルが見つかりません。');
            }

            $content = (string)($_POST['content'] ?? '');

            if (strlen($content) > 1024 * 1024) {
                throw new RuntimeException('テキストは1MB以内にしてください。');
            }

            $path = mcas_storage_file_path((string)$item['storage_key']);
            $tempPath = $path . '.tmp-' . bin2hex(random_bytes(8));

            if (file_put_contents($tempPath, $content, LOCK_EX) === false) {
                throw new RuntimeException('ファイルを保存できません。');
            }
            chmod($tempPath, 0640);

            if (!rename($tempPath, $path)) {
                @unlink($tempPath);
                throw new RuntimeException('ファイルを更新できません。');
            }

            $stmt = $pdo->prepare(
                'UPDATE mcas_storage_items
                 SET file_size = :file_size
                 WHERE id = :id AND owner_user_id = :owner_id'
            );
            $stmt->execute([
                ':file_size' => strlen($content),
                ':id' => (int)$item['id'],
                ':owner_id' => $userId,
            ]);

            $message = 'テキストを保存しました。';
            $parentId = $item['parent_id'] !== null ? (int)$item['parent_id'] : null;
        } elseif ($action === 'upload') {
            if (
                !isset($_FILES['upload']) ||
                !is_array($_FILES['upload']) ||
                (int)$_FILES['upload']['error'] !== UPLOAD_ERR_OK
            ) {
                throw new RuntimeException('アップロードに失敗しました。');
            }

            $upload = $_FILES['upload'];
            $maxBytes = 10 * 1024 * 1024;

            if ((int)$upload['size'] < 1 || (int)$upload['size'] > $maxBytes) {
                throw new RuntimeException('ファイルは10MB以下にしてください。');
            }

            $name = mcas_clean_display_name((string)$upload['name']);
            $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));

            // 実行ファイルや未知の形式は受け付けません。
            $allowed = [
                'txt'  => ['text/plain'],
                'md'   => ['text/plain', 'text/markdown'],
                'csv'  => ['text/plain', 'text/csv', 'application/vnd.ms-excel'],
                'pdf'  => ['application/pdf'],
                'jpg'  => ['image/jpeg'],
                'jpeg' => ['image/jpeg'],
                'png'  => ['image/png'],
                'gif'  => ['image/gif'],
                'webp' => ['image/webp'],
            ];

            if (!isset($allowed[$extension])) {
                throw new RuntimeException('この拡張子のファイルはアップロードできません。');
            }

            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file((string)$upload['tmp_name']);

            if (!is_string($mime) || !in_array($mime, $allowed[$extension], true)) {
                throw new RuntimeException('ファイルの種類を確認できませんでした。');
            }

            $key = bin2hex(random_bytes(32));
            $path = mcas_storage_file_path($key);

            if (!move_uploaded_file((string)$upload['tmp_name'], $path)) {
                throw new RuntimeException('アップロードファイルを保存できません。');
            }
            chmod($path, 0640);

            try {
                $stmt = $pdo->prepare(
                    "INSERT INTO mcas_storage_items
                        (tenant_id, owner_user_id, parent_id, item_type,
                         display_name, storage_key, mime_type, file_size)
                     VALUES
                        (:tenant_id, :owner_id, :parent_id, 'file',
                         :display_name, :storage_key, :mime_type, :file_size)"
                );
                $stmt->execute([
                    ':tenant_id' => $_SESSION['tenant_id'] ?? null,
                    ':owner_id' => $userId,
                    ':parent_id' => $postedParent,
                    ':display_name' => $name,
                    ':storage_key' => $key,
                    ':mime_type' => $mime,
                    ':file_size' => (int)$upload['size'],
                ]);
            } catch (Throwable $e) {
                @unlink($path);
                throw $e;
            }

            $message = 'ファイルをアップロードしました。';
            $parentId = $postedParent;
        } elseif ($action === 'delete') {
            $itemId = filter_input(INPUT_POST, 'item_id', FILTER_VALIDATE_INT);
            $item = $itemId ? mcas_owned_file_item((int)$itemId) : null;

            if (!$item) {
                throw new RuntimeException('削除する項目が見つかりません。');
            }

            if ($item['item_type'] === 'folder') {
                $stmt = $pdo->prepare(
                    'SELECT COUNT(*) FROM mcas_storage_items
                     WHERE parent_id = :parent_id AND owner_user_id = :owner_id'
                );
                $stmt->execute([
                    ':parent_id' => (int)$item['id'],
                    ':owner_id' => $userId,
                ]);

                if ((int)$stmt->fetchColumn() > 0) {
                    throw new RuntimeException('中身があるフォルダは削除できません。先に中の項目を削除してください。');
                }
            } elseif (!empty($item['storage_key'])) {
                $path = mcas_storage_file_path((string)$item['storage_key']);
                if (is_file($path) && !unlink($path)) {
                    throw new RuntimeException('ファイル本体を削除できません。');
                }
            }

            $stmt = $pdo->prepare(
                'DELETE FROM mcas_storage_items
                 WHERE id = :id AND owner_user_id = :owner_id'
            );
            $stmt->execute([
                ':id' => (int)$item['id'],
                ':owner_id' => $userId,
            ]);

            $message = '削除しました。';
            $parentId = $item['parent_id'] !== null ? (int)$item['parent_id'] : null;
        } else {
            throw new RuntimeException('操作を確認できません。');
        }
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}

$editId = isset($_GET['edit']) && ctype_digit((string)$_GET['edit'])
    ? (int)$_GET['edit']
    : null;
$editItem = $editId ? mcas_owned_file_item($editId) : null;
$editContent = null;

if (
    $editItem &&
    $editItem['item_type'] === 'file' &&
    preg_match('/\.(txt|md|csv)$/i', (string)$editItem['display_name'])
) {
    $path = mcas_storage_file_path((string)$editItem['storage_key']);
    if (is_file($path) && filesize($path) <= 1024 * 1024) {
        $editContent = file_get_contents($path);
    }
}

if ($parentId === null) {
    $stmt = $pdo->prepare(
        'SELECT id, parent_id, item_type, display_name, file_size
         FROM mcas_storage_items
         WHERE owner_user_id = :owner_id AND parent_id IS NULL
         ORDER BY item_type DESC, display_name ASC'
    );
    $stmt->execute([':owner_id' => $userId]);
} else {
    $stmt = $pdo->prepare(
        'SELECT id, parent_id, item_type, display_name, file_size
         FROM mcas_storage_items
         WHERE owner_user_id = :owner_id AND parent_id = :parent_id
         ORDER BY item_type DESC, display_name ASC'
    );
    $stmt->execute([
        ':owner_id' => $userId,
        ':parent_id' => $parentId,
    ]);
}

$items = $stmt->fetchAll();

$parentItem = $parentId !== null ? mcas_owned_file_item($parentId) : null;
$upId = $parentItem && $parentItem['parent_id'] !== null
    ? (int)$parentItem['parent_id']
    : null;
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ファイル管理 - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
    <style>
        .fm-panel { margin-top: 24px; padding: 20px; background: #fff;
            border: 1px solid #dce6f1; border-radius: 18px; }
        .fm-form { display: flex; flex-wrap: wrap; align-items: end; gap: 12px; }
        .fm-form label { display: grid; gap: 5px; font-weight: 700; }
        .fm-form input, .fm-form textarea { max-width: 100%; padding: 10px;
            border: 1px solid #cbd7e5; border-radius: 9px; font: inherit; }
        .fm-form button, .fm-delete button { min-height: 42px; padding: 8px 14px;
            border: 0; border-radius: 9px; background: #0759c7; color: white;
            font: inherit; font-weight: 700; cursor: pointer; }
        .fm-list { width: 100%; border-collapse: collapse; background: #fff; }
        .fm-list th, .fm-list td { padding: 12px 10px; border-bottom: 1px solid #e5edf5;
            text-align: left; vertical-align: middle; }
        .fm-list th { color: #42556c; font-size: .9rem; }
        .fm-inline { display: inline; }
        .fm-delete button { min-height: 34px; padding: 5px 10px; background: #9b2c2c; }
        .fm-alert { margin: 16px 0; padding: 12px 16px; background: #edf4fb;
            border-radius: 10px; }
        .fm-alert-error { color: #8b1e1e; background: #fff0f0; }
        .fm-editor { width: 100%; min-height: 240px; }
        @media (max-width: 640px) {
            .fm-list th:nth-child(3), .fm-list td:nth-child(3) { display: none; }
            .fm-list th, .fm-list td { padding: 9px 6px; font-size: .9rem; }
        }
    </style>
</head>
<body>
<header class="mcas-header">
    <div class="mcas-header-inner">
        <a class="mcas-brand" href="/product.php">
            <span class="mcas-brand-name"><?= mcas_e(MCAS_APP_NAME) ?></span>
        </a>
        <nav class="mcas-nav" aria-label="メインメニュー">
            <a href="/product.php">紹介ページ</a>
            <a href="/features.php">機能紹介</a>
            <a href="/files/">ファイル管理</a>
        </nav>
    </div>
</header>

<main class="mcas-container">
    <h1>ファイル管理</h1>
    <p>ファイルは公開フォルダの外に保存されます。現在は自分が登録した項目だけ表示します。</p>

    <?php if ($message !== ''): ?>
        <p class="fm-alert"><?= mcas_e($message) ?></p>
    <?php endif; ?>
    <?php if ($error !== ''): ?>
        <p class="fm-alert fm-alert-error" role="alert"><?= mcas_e($error) ?></p>
    <?php endif; ?>

    <p>
        <?php if ($parentId !== null): ?>
            <a href="<?= $upId !== null ? '?parent=' . $upId : '/files/' ?>">上のフォルダへ</a>
        <?php else: ?>
            ルートフォルダ
        <?php endif; ?>
    </p>

    <section class="fm-panel">
        <h2>フォルダ・テキストファイルを作成</h2>
        <form class="fm-form" method="post">
            <input type="hidden" name="csrf_token" value="<?= mcas_e(mcas_csrf_token()) ?>">
            <input type="hidden" name="parent_id" value="<?= $parentId ?? '' ?>">

            <label>
                フォルダ名
                <input type="text" name="name" maxlength="255">
            </label>
            <button type="submit" name="action" value="create_folder">フォルダ作成</button>
        </form>

        <form class="fm-form" method="post" style="margin-top: 14px">
            <input type="hidden" name="csrf_token" value="<?= mcas_e(mcas_csrf_token()) ?>">
            <input type="hidden" name="parent_id" value="<?= $parentId ?? '' ?>">

            <label>
                テキストファイル名
                <input type="text" name="name" maxlength="255" placeholder="メモ.txt">
            </label>
            <button type="submit" name="action" value="create_text">作成</button>
        </form>
    </section>

    <section class="fm-panel">
        <h2>ファイルをアップロード</h2>
        <form class="fm-form" method="post" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= mcas_e(mcas_csrf_token()) ?>">
            <input type="hidden" name="parent_id" value="<?= $parentId ?? '' ?>">
            <input type="hidden" name="MAX_FILE_SIZE" value="10485760">

            <label>
                ファイル（最大10MB）
                <input type="file" name="upload" required>
            </label>
            <button type="submit" name="action" value="upload">アップロード</button>
        </form>
        <p>対応形式：TXT、MD、CSV、PDF、JPG、PNG、GIF、WEBP</p>
    </section>

    <?php if ($editContent !== null && $editItem): ?>
        <section class="fm-panel">
            <h2><?= mcas_e($editItem['display_name']) ?> を編集</h2>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= mcas_e(mcas_csrf_token()) ?>">
                <input type="hidden" name="item_id" value="<?= (int)$editItem['id'] ?>">
                <textarea class="fm-editor" name="content" maxlength="1048576"><?= mcas_e($editContent) ?></textarea>
                <p><button class="fm-form" type="submit" name="action" value="save_text">保存</button></p>
                <a href="/files/share.php?id=<?= (int)$item['id'] ?>">共有設定</a>
            </form>
        </section>
    <?php endif; ?>

    <section class="fm-panel">
        <h2>保存項目</h2>
        <table class="fm-list">
            <thead>
                <tr><th>名前</th><th>操作</th><th>サイズ</th><th>削除</th></tr>
            </thead>
            <tbody>
            <?php if (!$items): ?>
                <tr><td colspan="4">このフォルダは空です。</td></tr>
            <?php endif; ?>

            <?php foreach ($items as $item): ?>
                <tr>
                    <td>
                        <?php if ($item['item_type'] === 'folder'): ?>
                            <a href="?parent=<?= (int)$item['id'] ?>">
                                📁 <?= mcas_e($item['display_name']) ?>
                            </a>
                        <?php else: ?>
                            <?= mcas_e($item['display_name']) ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($item['item_type'] === 'file'): ?>
                            <a href="/files/download.php?id=<?= (int)$item['id'] ?>">ダウンロード</a>
                            <?php if (preg_match('/\.(txt|md|csv)$/i', (string)$item['display_name'])): ?>
                                | <a href="?edit=<?= (int)$item['id'] ?>">編集</a>
                            <?php endif; ?>
                        <?php else: ?>
                            フォルダ
                        <?php endif; ?>
                    </td>
                    <td><?= number_format((int)$item['file_size']) ?> bytes</td>
                    <td>
                        <form class="fm-delete" method="post"
                              onsubmit="return confirm('この項目を削除しますか？');">
                            <input type="hidden" name="csrf_token"
                                   value="<?= mcas_e(mcas_csrf_token()) ?>">
                            <input type="hidden" name="parent_id" value="<?= $parentId ?? '' ?>">
                            <input type="hidden" name="item_id" value="<?= (int)$item['id'] ?>">
                            <button type="submit" name="action" value="delete">削除</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>
</body>
</html>