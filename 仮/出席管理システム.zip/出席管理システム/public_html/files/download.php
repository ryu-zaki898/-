<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/file_manager.php';

mcas_require_login();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(404);
    exit('ファイルが見つかりません。');
}

$item = mcas_owned_file_item((int)$id);

if (!$item || $item['item_type'] !== 'file' || empty($item['storage_key'])) {
    http_response_code(404);
    exit('ファイルが見つかりません。');
}

try {
    $path = mcas_storage_file_path((string)$item['storage_key']);
} catch (Throwable $e) {
    http_response_code(500);
    exit('保存先を確認できません。');
}

if (!is_file($path) || !is_readable($path)) {
    http_response_code(404);
    exit('ファイル本体が見つかりません。');
}

$name = str_replace(["\r", "\n", '"'], '', (string)$item['display_name']);
$mime = (string)($item['mime_type'] ?: 'application/octet-stream');

header('Content-Type: ' . $mime);
header('Content-Length: ' . (string)filesize($path));
header('Content-Disposition: attachment; filename="' . addslashes($name) . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');

readfile($path);
exit;