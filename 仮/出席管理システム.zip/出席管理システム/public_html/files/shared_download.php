<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/share_manager.php';

$token = (string)($_GET['t'] ?? '');
$share = mcas_find_share($token);

if (!$share) {
    http_response_code(404);
    exit('共有リンクが見つからないか、有効期限が切れています。');
}

mcas_require_share_password($share);

try {
    $path = mcas_storage_file_path((string)$share['storage_key']);
} catch (Throwable $e) {
    http_response_code(500);
    exit('ファイルの保存先を確認できません。');
}

if (!is_file($path) || !is_readable($path)) {
    http_response_code(404);
    exit('ファイル本体が見つかりません。');
}

$name = str_replace(["\r", "\n", '"'], '', (string)$share['display_name']);

header('Content-Type: application/octet-stream');
header('Content-Length: ' . (string)filesize($path));
header('Content-Disposition: attachment; filename="' . addslashes($name) . '"');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');

readfile($path);
exit;