<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/share_manager.php';

$token = (string)($_GET['t'] ?? '');
$share = mcas_find_share($token);

if (!$share) {
    http_response_code(404);
    exit('共有リンクが見つからないか、有効期限が切れています。');
}

mcas_require_share_password($share);
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>共有ファイル</title>
</head>
<body>
<main>
    <h1>共有ファイル</h1>
    <p>ファイル名：<?= htmlspecialchars(
        (string)$share['display_name'],
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    ) ?></p>
    <p>サイズ：<?= number_format((int)$share['file_size']) ?> bytes</p>
    <p>
        <a href="/files/shared_download.php?t=<?= rawurlencode($token) ?>">
            ファイルをダウンロード
        </a>
    </p>
</main>
</body>
</html>