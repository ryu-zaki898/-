<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

mcas_require_login();

$config = $GLOBALS['config'] ?? [];
$vapid = $config['vapid'] ?? [];
$publicKey = (string)($vapid['public_key'] ?? '');
$csrfToken = mcas_csrf_token();

$stmt = mcas_db()->prepare(
    'SELECT title, body, is_read, created_at
     FROM notifications
     WHERE target_user_id = :user_id
       AND tenant_id = :tenant_id
     ORDER BY created_at DESC
     LIMIT 50'
);
$stmt->execute([
    ':user_id' => (int)$_SESSION['user_id'],
    ':tenant_id' => (int)($_SESSION['tenant_id'] ?? 0),
]);
$notifications = $stmt->fetchAll();

function mcas_push_page_e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>通知 - <?= mcas_push_page_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
    <style>
        .push-panel, .notice-item { margin-top: 18px; padding: 18px; background: #fff;
            border: 1px solid #dce6f1; border-radius: 16px; }
        .push-panel button { margin: 6px 8px 6px 0; padding: 10px 14px;
            border: 0; border-radius: 9px; color: #fff; background: #0759c7;
            font: inherit; font-weight: 700; cursor: pointer; }
        .push-panel button:disabled { opacity: .55; cursor: not-allowed; }
        #push-message { min-height: 1.5em; }
    </style>
</head>
<body>
<header class="mcas-header">
    <div class="mcas-header-inner">
        <a class="mcas-brand" href="/product.php">
            <span class="mcas-brand-name"><?= mcas_push_page_e(MCAS_APP_NAME) ?></span>
        </a>
        <nav class="mcas-nav" aria-label="メインメニュー">
            <a href="/files/">ファイル管理</a>
            <a href="/links/">サイトリンク</a>
        </nav>
    </div>
</header>

<main class="mcas-container">
    <h1>通知</h1>

    <section class="push-panel">
        <h2>ブラウザー通知</h2>
        <p>通知を受け取るには、ブラウザーからの許可が必要です。</p>

        <button type="button" id="subscribe-button">通知を有効にする</button>
        <button type="button" id="unsubscribe-button">通知を解除する</button>
        <button type="button" id="test-button">自分にテスト通知を送る</button>

        <p id="push-message" role="status" aria-live="polite"></p>
    </section>

    <section class="mcas-section">
        <h2>アプリ内通知</h2>

        <?php if (!$notifications): ?>
            <p>通知はまだありません。</p>
        <?php endif; ?>

        <?php foreach ($notifications as $notification): ?>
            <article class="notice-item">
                <h3><?= mcas_push_page_e($notification['title']) ?></h3>
                <p><?= nl2br(mcas_push_page_e($notification['body'])) ?></p>
                <small><?= mcas_push_page_e($notification['created_at']) ?></small>
            </article>
        <?php endforeach; ?>
    </section>
</main>

<script>
"use strict";

const vapidPublicKey = <?= json_encode(
    $publicKey,
    JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
) ?>;
const csrfToken = <?= json_encode(
    $csrfToken,
    JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
) ?>;

const messageElement = document.getElementById("push-message");

function setMessage(text) {
    messageElement.textContent = text;
}

function base64UrlToUint8Array(value) {
    const padding = "=".repeat((4 - value.length % 4) % 4);
    const base64 = (value + padding).replace(/-/g, "+").replace(/_/g, "/");
    const raw = window.atob(base64);
    return Uint8Array.from(raw, (character) => character.charCodeAt(0));
}

async function apiRequest(data) {
    const response = await fetch("/notifications/api.php", {
        method: "POST",
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json",
            "X-CSRF-Token": csrfToken
        },
        body: JSON.stringify(data)
    });

    const result = await response.json();

    if (!response.ok || !result.ok) {
        throw new Error(result.message || "通知処理に失敗しました。");
    }

    return result;
}

document.getElementById("subscribe-button").addEventListener("click", async () => {
    try {
        if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
            throw new Error("このブラウザーはWeb Push通知に対応していません。");
        }

        if (!vapidPublicKey) {
            throw new Error("VAPID公開鍵が設定されていません。");
        }

        const permission = await Notification.requestPermission();
        if (permission !== "granted") {
            throw new Error("ブラウザーの通知許可が必要です。");
        }

        const registration = await navigator.serviceWorker.register("/sw.js");
        const subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: base64UrlToUint8Array(vapidPublicKey)
        });

        const result = await apiRequest({
            action: "subscribe",
            subscription: subscription.toJSON()
        });

        setMessage(result.message);
    } catch (error) {
        setMessage(error.message || "通知を有効にできませんでした。");
    }
});

document.getElementById("unsubscribe-button").addEventListener("click", async () => {
    try {
        const registration = await navigator.serviceWorker.getRegistration("/");
        const subscription = registration
            ? await registration.pushManager.getSubscription()
            : null;

        if (!subscription) {
            setMessage("このブラウザーは通知を購読していません。");
            return;
        }

        const result = await apiRequest({
            action: "unsubscribe",
            endpoint: subscription.endpoint
        });

        await subscription.unsubscribe();
        setMessage(result.message);
    } catch (error) {
        setMessage(error.message || "通知を解除できませんでした。");
    }
});

document.getElementById("test-button").addEventListener("click", async () => {
    try {
        const result = await apiRequest({ action: "send_test" });
        setMessage(result.message);
    } catch (error) {
        setMessage(error.message || "テスト通知を送れませんでした。");
    }
});
</script>
</body>
</html>