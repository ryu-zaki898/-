<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/push_service.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function mcas_json_response(int $status, array $data): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    mcas_json_response(405, ['ok' => false, 'message' => 'POSTのみ利用できます。']);
}

if (empty($_SESSION['user_id'])) {
    mcas_json_response(401, ['ok' => false, 'message' => 'ログインしてください。']);
}

$csrf = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
$savedCsrf = (string)($_SESSION['mcas_csrf_token'] ?? '');

if ($csrf === '' || $savedCsrf === '' || !hash_equals($savedCsrf, $csrf)) {
    mcas_json_response(403, ['ok' => false, 'message' => 'ページを再読み込みしてください。']);
}

$input = json_decode((string)file_get_contents('php://input'), true);

if (!is_array($input)) {
    mcas_json_response(400, ['ok' => false, 'message' => '送信データを読み取れません。']);
}

$userId = (int)$_SESSION['user_id'];
$tenantId = isset($_SESSION['tenant_id']) ? (int)$_SESSION['tenant_id'] : 0;

if ($tenantId < 1) {
    mcas_json_response(403, [
        'ok' => false,
        'message' => '団体に所属する利用者アカウントが必要です。',
    ]);
}

$action = (string)($input['action'] ?? '');

try {
    if ($action === 'subscribe') {
        $subscription = $input['subscription'] ?? null;

        if (!is_array($subscription)) {
            mcas_json_response(400, ['ok' => false, 'message' => '購読情報がありません。']);
        }

        $endpoint = (string)($subscription['endpoint'] ?? '');
        $keys = $subscription['keys'] ?? [];
        $p256dh = is_array($keys) ? (string)($keys['p256dh'] ?? '') : '';
        $auth = is_array($keys) ? (string)($keys['auth'] ?? '') : '';

        if (
            strlen($endpoint) > 2000 ||
            !filter_var($endpoint, FILTER_VALIDATE_URL) ||
            strtolower((string)parse_url($endpoint, PHP_URL_SCHEME)) !== 'https' ||
            $p256dh === '' ||
            $auth === '' ||
            strlen($p256dh) > 255 ||
            strlen($auth) > 255
        ) {
            mcas_json_response(400, ['ok' => false, 'message' => '購読情報の形式が正しくありません。']);
        }

        $endpointHash = hash('sha256', $endpoint);

        $stmt = mcas_db()->prepare(
            'INSERT INTO push_subscriptions
                (tenant_id, user_id, endpoint_hash, endpoint,
                 p256dh_key, auth_key, content_encoding)
             VALUES
                (:tenant_id, :user_id, :endpoint_hash, :endpoint,
                 :p256dh, :auth, :content_encoding)
             ON DUPLICATE KEY UPDATE
                tenant_id = VALUES(tenant_id),
                user_id = VALUES(user_id),
                endpoint = VALUES(endpoint),
                p256dh_key = VALUES(p256dh_key),
                auth_key = VALUES(auth_key),
                content_encoding = VALUES(content_encoding),
                updated_at = CURRENT_TIMESTAMP'
        );
        $stmt->execute([
            ':tenant_id' => $tenantId,
            ':user_id' => $userId,
            ':endpoint_hash' => $endpointHash,
            ':endpoint' => $endpoint,
            ':p256dh' => $p256dh,
            ':auth' => $auth,
            ':content_encoding' => 'aes128gcm',
        ]);

        mcas_json_response(200, ['ok' => true, 'message' => '通知を購読しました。']);
    }

    if ($action === 'unsubscribe') {
        $endpoint = (string)($input['endpoint'] ?? '');

        if (
            $endpoint === '' ||
            strlen($endpoint) > 2000 ||
            !filter_var($endpoint, FILTER_VALIDATE_URL)
        ) {
            mcas_json_response(400, ['ok' => false, 'message' => '購読情報を確認できません。']);
        }

        $stmt = mcas_db()->prepare(
            'DELETE FROM push_subscriptions
             WHERE endpoint_hash = :endpoint_hash
               AND user_id = :user_id
               AND tenant_id = :tenant_id'
        );
        $stmt->execute([
            ':endpoint_hash' => hash('sha256', $endpoint),
            ':user_id' => $userId,
            ':tenant_id' => $tenantId,
        ]);

        mcas_json_response(200, ['ok' => true, 'message' => '通知の購読を解除しました。']);
    }

    if ($action === 'send_test') {
        $result = mcas_send_push_to_user(
            $userId,
            $tenantId,
            '通知テスト',
            'MyControlAssociationSystemからのテスト通知です。'
        );

        mcas_json_response(200, [
            'ok' => true,
            'message' => $result['message'],
        ]);
    }

    mcas_json_response(400, ['ok' => false, 'message' => '操作を確認できません。']);
} catch (Throwable $e) {
    error_log('MCAS notification API error: ' . $e->getMessage());
    mcas_json_response(500, [
        'ok' => false,
        'message' => '通知処理に失敗しました。設定とサーバーログを確認してください。',
    ]);
}