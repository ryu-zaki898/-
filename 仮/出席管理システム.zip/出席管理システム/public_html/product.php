<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/app/bootstrap.php';

$iconFile = __DIR__ . '/assets/images/app-icon.jpg';
$devicesFile = __DIR__ . '/assets/images/product-devices.jpg';
$featuresUrl = '/features.php';
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
          content="団体の出席管理や日々の情報共有を支援するMyControlAssociationSystemの製品紹介ページです。">
    <title>製品紹介 - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<header class="mcas-header">
    <div class="mcas-header-inner">
        <a class="mcas-brand" href="/product.php">
            <?php if (is_file($iconFile)): ?>
                <img src="/assets/images/app-icon.jpg"
                     alt="<?= mcas_e(MCAS_APP_NAME) ?> アプリアイコン">
            <?php endif; ?>
            <span class="mcas-brand-name"><?= mcas_e(MCAS_APP_NAME) ?></span>
        </a>

        <nav class="mcas-nav" aria-label="メインメニュー">
            <a href="/product.php" aria-current="page">製品紹介</a>
            <a href="<?= mcas_e($featuresUrl) ?>">機能紹介</a>
            <a href="/login.php">ログイン</a>
        </nav>
    </div>
</header>

<main class="mcas-container">
    <section class="mcas-hero">
        <div>
            <span class="mcas-eyebrow">Association management</span>
            <h1>団体の活動を、<br>ひとつの場所で。</h1>
            <p>
                <?= mcas_e(MCAS_APP_NAME) ?> は、団体の出席管理を中心に、
                情報や作業をまとめて扱うことを目指すアプリです。
                パソコンとスマートフォンの画面に対応する構成で開発しています。
            </p>

            <div class="mcas-actions">
                <a class="mcas-button" href="<?= mcas_e($featuresUrl) ?>">
                    機能を見る
                </a>
                <a class="mcas-button mcas-button-secondary" href="/login.php">
                    ログイン
                </a>
            </div>
        </div>

        <div class="mcas-hero-image">
            <?php if (is_file($devicesFile)): ?>
                <img src="/assets/images/product-devices.jpg"
                     alt="スマートフォンとパソコンで使うMyControlAssociationSystem">
            <?php else: ?>
                <div class="mcas-device-placeholder">
                    <strong>携帯・パソコンの利用イメージ</strong>
                    <span>
                        撮影した画像を
                        <code>assets/images/product-devices.jpg</code>
                        の名前で置くと、ここに表示されます。
                    </span>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="mcas-section">
        <div class="mcas-section-heading">
            <h2>団体の運営を、見やすく整理</h2>
            <p>
                既存の出席管理を土台に、日々の運営で使う機能を順番に追加していく構成です。
            </p>
        </div>

        <div class="mcas-card-grid">
            <article class="mcas-card">
                <h3>出席管理を中心に</h3>
                <p>団体の活動で使う出席管理を中心に、必要な情報へアクセスしやすくします。</p>
            </article>

            <article class="mcas-card">
                <h3>パソコン・スマートフォンに対応</h3>
                <p>画面幅に合わせたレイアウトで、パソコンと携帯の両方で使いやすい表示を目指します。</p>
            </article>

            <article class="mcas-card">
                <h3>機能を追加しやすい構成</h3>
                <p>ファイル管理や通知などを、既存の画面を残しながら段階的に追加する設計です。</p>
            </article>
        </div>

        <div class="mcas-note">
            ここに記載した追加機能は、実装・動作確認が終わるまでは利用可能な機能として案内しません。
        </div>
    </section>
</main>

<footer class="mcas-footer">
    <div class="mcas-footer-inner">
        <span><?= mcas_e(MCAS_APP_NAME) ?></span>
        <a href="/features.php">機能紹介を見る</a>
    </div>
</footer>
</body>
</html>