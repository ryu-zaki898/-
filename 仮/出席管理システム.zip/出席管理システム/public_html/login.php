<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/app/auth.php';

if (mcas_is_logged_in()) {
    header('Location: /');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        mcas_verify_csrf();

        $loginId = trim((string)($_POST['login_id'] ?? ''));
        $password = (string)($_POST['password'] ?? '');

        if ($loginId === '' || $password === '') {
            throw new RuntimeException('ログインIDとパスワードを入力してください。');
        }

        $pdo = mcas_db();
        $stmt = $pdo->prepare(
            'SELECT id, tenant_id, login_id, password_hash, display_name,
                    role, is_active, failed_login_count, locked_until
             FROM users
             WHERE login_id = :login_id
             LIMIT 1'
        );
        $stmt->execute([':login_id' => $loginId]);
        $user = $stmt->fetch();

        $now = new DateTimeImmutable('now');

        if (
            !$user ||
            (int)$user['is_active'] !== 1 ||
            !empty($user['locked_until']) &&
                new DateTimeImmutable((string)$user['locked_until']) > $now
        ) {
            throw new RuntimeException('ログインできません。入力内容をご確認ください。');
        }

        if (!password_verify($password, (string)$user['password_hash'])) {
            $failedCount = (int)$user['failed_login_count'] + 1;
            $lockedUntil = $failedCount >= 5
                ? $now->modify('+15 minutes')->format('Y-m-d H:i:s')
                : null;

            $update = $pdo->prepare(
                'UPDATE users
                 SET failed_login_count = :failed_count,
                     locked_until = :locked_until
                 WHERE id = :id'
            );
            $update->execute([
                ':failed_count' => $failedCount,
                ':locked_until' => $lockedUntil,
                ':id' => (int)$user['id'],
            ]);

            throw new RuntimeException('ログインできません。入力内容をご確認ください。');
        }

        $update = $pdo->prepare(
            'UPDATE users
             SET failed_login_count = 0, locked_until = NULL
             WHERE id = :id'
        );
        $update->execute([':id' => (int)$user['id']]);

        session_regenerate_id(true);

        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['tenant_id'] = $user['tenant_id'] !== null
            ? (int)$user['tenant_id']
            : null;
        $_SESSION['login_id'] = (string)$user['login_id'];
        $_SESSION['display_name'] = (string)$user['display_name'];
        $_SESSION['role'] = (string)$user['role'];

        header('Location: /');
        exit;
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ログイン - MyControlAssociationSystem</title>
</head>
<body>
<main>
    <h1>MyControlAssociationSystem</h1>
    <h2>ログイン</h2>

    <?php if ($error !== ''): ?>
        <p role="alert"><?= mcas_e($error) ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <input type="hidden" name="csrf_token"
               value="<?= mcas_e(mcas_csrf_token()) ?>">

        <label>
            ログインID
            <input type="text" name="login_id" required autocomplete="username">
        </label>

        <label>
            パスワード
            <input type="password" name="password" required
                   autocomplete="current-password">
        </label>

        <button type="submit">ログイン</button>
    </form>

    <p><a href="/install_admin.php">初めて使う場合の管理者登録</a></p>
</main>
</body>
</html>