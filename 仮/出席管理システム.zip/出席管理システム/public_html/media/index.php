<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

mcas_require_login();

$csrfToken = mcas_csrf_token();
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>写真・動画 - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
    <style>
        .media-panel {
            margin-top: 20px;
            padding: 20px;
            background: #fff;
            border: 1px solid #dce6f1;
            border-radius: 18px;
        }
        .media-preview {
            display: block;
            width: 100%;
            max-height: 65vh;
            background: #111;
            border-radius: 14px;
        }
        .media-controls {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 14px;
        }
        .media-controls button {
            min-height: 44px;
            padding: 9px 15px;
            border: 0;
            border-radius: 9px;
            background: #0759c7;
            color: #fff;
            font: inherit;
            font-weight: 700;
            cursor: pointer;
        }
        .media-controls button:disabled {
            opacity: .5;
            cursor: not-allowed;
        }
        #media-message {
            min-height: 1.5em;
        }
    </style>
</head>
<body>
<header class="mcas-header">
    <div class="mcas-header-inner">
        <a class="mcas-brand" href="/product.php">
            <span class="mcas-brand-name"><?= mcas_e(MCAS_APP_NAME) ?></span>
        </a>
        <nav class="mcas-nav" aria-label="メインメニュー">
            <a href="/files/">ファイル管理</a>
            <a href="/notifications/">通知</a>
            <a href="/meet/">会議リンク</a>
        </nav>
    </div>
</header>

<main class="mcas-container">
    <h1>写真・動画</h1>
    <p>撮影したデータは非公開の保存領域に保存されます。</p>

    <section class="media-panel">
        <video id="camera-preview" class="media-preview" autoplay muted playsinline></video>

        <div class="media-controls">
            <button id="start-camera" type="button">カメラを開始</button>
            <button id="take-photo" type="button" disabled>写真を撮影</button>
            <button id="start-recording" type="button" disabled>動画を録画</button>
            <button id="stop-recording" type="button" disabled>録画を停止</button>
            <button id="stop-camera" type="button" disabled>カメラを終了</button>
        </div>

        <p id="media-message" role="status" aria-live="polite"></p>
        <canvas id="photo-canvas" hidden></canvas>
    </section>
</main>

<script>
"use strict";

const csrfToken = <?= json_encode(
    $csrfToken,
    JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
) ?>;

const preview = document.getElementById("camera-preview");
const message = document.getElementById("media-message");
const startCameraButton = document.getElementById("start-camera");
const takePhotoButton = document.getElementById("take-photo");
const startRecordingButton = document.getElementById("start-recording");
const stopRecordingButton = document.getElementById("stop-recording");
const stopCameraButton = document.getElementById("stop-camera");
const canvas = document.getElementById("photo-canvas");

let cameraStream = null;
let recorder = null;
let recordedChunks = [];

function showMessage(text) {
    message.textContent = text;
}

function setCameraButtons(active) {
    takePhotoButton.disabled = !active;
    startRecordingButton.disabled = !active || recorder !== null;
    stopCameraButton.disabled = !active || recorder !== null;
}

async function startCamera() {
    if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error("このブラウザーではカメラを利用できません。HTTPS接続か確認してください。");
    }

    cameraStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" } },
        audio: true
    });

    preview.srcObject = cameraStream;
    setCameraButtons(true);
    startCameraButton.disabled = true;
    showMessage("カメラを開始しました。利用後はカメラを終了してください。");
}

function stopCamera() {
    if (cameraStream) {
        for (const track of cameraStream.getTracks()) {
            track.stop();
        }
    }

    cameraStream = null;
    preview.srcObject = null;
    startCameraButton.disabled = false;
    setCameraButtons(false);
    showMessage("カメラを終了しました。");
}

async function uploadBlob(blob, filename, mediaType) {
    const formData = new FormData();
    formData.append("csrf_token", csrfToken);
    formData.append("media_type", mediaType);
    formData.append("media_file", blob, filename);

    const response = await fetch("/media/upload.php", {
        method: "POST",
        credentials: "same-origin",
        body: formData
    });

    const result = await response.json();

    if (!response.ok || !result.ok) {
        throw new Error(result.message || "ファイルを保存できませんでした。");
    }

    showMessage(result.message);
}

startCameraButton.addEventListener("click", async () => {
    try {
        await startCamera();
    } catch (error) {
        showMessage(error.message || "カメラを開始できませんでした。");
    }
});

takePhotoButton.addEventListener("click", async () => {
    try {
        if (!cameraStream || !preview.videoWidth || !preview.videoHeight) {
            throw new Error("カメラ映像を取得できません。");
        }

        canvas.width = preview.videoWidth;
        canvas.height = preview.videoHeight;

        const context = canvas.getContext("2d");
        context.drawImage(preview, 0, 0, canvas.width, canvas.height);

        const blob = await new Promise((resolve) => {
            canvas.toBlob(resolve, "image/jpeg", 0.9);
        });

        if (!blob) {
            throw new Error("写真を作成できませんでした。");
        }

        showMessage("写真を保存しています。");
        await uploadBlob(blob, "photo.jpg", "photo");
    } catch (error) {
        showMessage(error.message || "写真を保存できませんでした。");
    }
});

startRecordingButton.addEventListener("click", () => {
    try {
        if (!cameraStream || !window.MediaRecorder) {
            throw new Error("このブラウザーでは動画録画を利用できません。");
        }

        const supportedTypes = [
            "video/webm;codecs=vp9,opus",
            "video/webm;codecs=vp8,opus",
            "video/webm",
            "video/mp4"
        ];

        const mimeType = supportedTypes.find((type) =>
            MediaRecorder.isTypeSupported(type)
        );

        recorder = mimeType
            ? new MediaRecorder(cameraStream, { mimeType })
            : new MediaRecorder(cameraStream);

        recordedChunks = [];

        recorder.addEventListener("dataavailable", (event) => {
            if (event.data && event.data.size > 0) {
                recordedChunks.push(event.data);
            }
        });

        recorder.addEventListener("stop", async () => {
            try {
                const blob = new Blob(recordedChunks, {
                    type: recorder.mimeType || "video/webm"
                });

                if (blob.size === 0) {
                    throw new Error("動画データがありません。");
                }

                const isMp4 = blob.type.includes("mp4");
                const filename = isMp4 ? "video.mp4" : "video.webm";

                showMessage("動画を保存しています。");
                await uploadBlob(blob, filename, "video");
            } catch (error) {
                showMessage(error.message || "動画を保存できませんでした。");
            } finally {
                recorder = null;
                stopRecordingButton.disabled = true;
                startRecordingButton.disabled = !cameraStream;
                stopCameraButton.disabled = !cameraStream;
            }
        });

        recorder.start();
        startRecordingButton.disabled = true;
        stopRecordingButton.disabled = false;
        stopCameraButton.disabled = true;
        showMessage("録画中です。録画を止めると保存を開始します。");
    } catch (error) {
        recorder = null;
        showMessage(error.message || "録画を開始できませんでした。");
    }
});

stopRecordingButton.addEventListener("click", () => {
    if (recorder && recorder.state !== "inactive") {
        recorder.stop();
        stopRecordingButton.disabled = true;
    }
});

stopCameraButton.addEventListener("click", () => {
    if (recorder && recorder.state !== "inactive") {
        showMessage("録画を停止してからカメラを終了してください。");
        return;
    }
    stopCamera();
});

window.addEventListener("pagehide", () => {
    if (cameraStream) {
        for (const track of cameraStream.getTracks()) {
            track.stop();
        }
    }
});
</script>
</body>
</html>