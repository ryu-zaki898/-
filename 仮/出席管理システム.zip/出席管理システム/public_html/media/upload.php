<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/file_manager.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function mcas_media_response(int $status, array $data): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    mcas_media_response(405, [
        'ok' => false,
        'message' => 'POSTのみ利用できます。',
    ]);
}

if (empty($_SESSION['user_id'])) {
    mcas_media_response(401, [
        'ok' => false,
        'message' => 'ログインしてください。',
    ]);
}

$postedToken = (string)($_POST['csrf_token'] ?? '');
$savedToken = (string)($_SESSION['mcas_csrf_token'] ?? '');

if ($postedToken === '' || $savedToken === '' || !hash_equals($savedToken, $postedToken)) {
    mcas_media_response(403, [
        'ok' => false,
        'message' => 'ページを再読み込みしてから、もう一度お試しください。',
    ]);
}

if (
    !isset($_FILES['media_file']) ||
    !is_array($_FILES['media_file']) ||
    (int)$_FILES['media_file']['error'] !== UPLOAD_ERR_OK
) {
    mcas_media_response(400, [
        'ok' => false,
        'message' => 'アップロードに失敗しました。サーバーのアップロード上限も確認してください。',
    ]);
}

$file = $_FILES['media_file'];
$maxBytes = 50 * 1024 * 1024;

if (
    (int)$file['size'] < 1 ||
    (int)$file['size'] > $maxBytes ||
    !is_uploaded_file((string)$file['tmp_name'])
) {
    mcas_media_response(400, [
        'ok' => false,
        'message' => 'ファイルが空か、50MBの上限を超えています。',
    ]);
}

$mediaType = (string)($_POST['media_type'] ?? '');
$finfo = new finfo(FILEINFO_MIME_TYPE);
$detectedMime = $finfo->file((string)$file['tmp_name']);

if (!is_string($detectedMime)) {
    mcas_media_response(400, [
        'ok' => false,
        'message' => 'ファイル形式を確認できませんでした。',
    ]);
}

if ($mediaType === 'photo') {
    $imageInfo = @getimagesize((string)$file['tmp_name']);

    if (
        $detectedMime !== 'image/jpeg' ||
        !$imageInfo ||
        ($imageInfo[2] ?? null) !== IMAGETYPE_JPEG
    ) {
        mcas_media_response(400, [
            'ok' => false,
            'message' => '写真はJPEG形式で保存してください。',
        ]);
    }

    $displayName = 'photo-' . date('Ymd-His') . '.jpg';
    $mimeType = 'image/jpeg';
} elseif ($mediaType === 'video') {
    $head = file_get_contents((string)$file['tmp_name'], false, null, 0, 16);

    $isWebm = is_string($head) &&
        str_starts_with($head, "\x1A\x45\xDF\xA3") &&
        in_array($detectedMime, ['video/webm', 'application/octet-stream'], true);

    $isMp4 = is_string($head) &&
        strlen($head) >= 8 &&
        substr($head, 4, 4) === 'ftyp' &&
        in_array($detectedMime, ['video/mp4', 'application/mp4', 'application/octet-stream'], true);

    if (!$isWebm && !$isMp4) {
        mcas_media_response(400, [
            'ok' => false,
            'message' => '動画はWebMまたはMP4形式にしてください。',
        ]);
    }

    if ($isMp4) {
        $displayName = 'video-' . date('Ymd-His') . '.mp4';
        $mimeType = 'video/mp4';
    } else {
        $displayName = 'video-' . date('Ymd-His') . '.webm';
        $mimeType = 'video/webm';
    }
} else {
    mcas_media_response(400, [
        'ok' => false,
        'message' => '写真または動画を指定してください。',
    ]);
}

$storageKey = bin2hex(random_bytes(32));

try {
    $targetPath = mcas_storage_file_path($storageKey);

    if (!move_uploaded_file((string)$file['tmp_name'], $targetPath)) {
        throw new RuntimeException('ファイルを保存できませんでした。');
    }

    chmod($targetPath, 0640);

    $pdo = mcas_db();
    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        "INSERT INTO mcas_storage_items
            (tenant_id, owner_user_id, parent_id, item_type,
             display_name, storage_key, mime_type, file_size)
         VALUES
            (:tenant_id, :owner_id, NULL, 'file',
             :display_name, :storage_key, :mime_type, :file_size)"
    );
    $stmt->execute([
        ':tenant_id' => $_SESSION['tenant_id'] ?? null,
        ':owner_id' => (int)$_SESSION['user_id'],
        ':display_name' => $displayName,
        ':storage_key' => $storageKey,
        ':mime_type' => $mimeType,
        ':file_size' => (int)$file['size'],
    ]);

    $storageItemId = (int)$pdo->lastInsertId();

    $stmt = $pdo->prepare(
        'INSERT INTO mcas_media_items
            (storage_item_id, media_type, recorded_by_user_id)
         VALUES
            (:storage_item_id, :media_type, :user_id)'
    );
    $stmt->execute([
        ':storage_item_id' => $storageItemId,
        ':media_type' => $mediaType,
        ':user_id' => (int)$_SESSION['user_id'],
    ]);

    $pdo->commit();

    mcas_media_response(200, [
        'ok' => true,
        'message' => '撮影データを保存しました。ファイル管理から確認できます。',
    ]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    if (isset($targetPath) && is_file($targetPath)) {
        @unlink($targetPath);
    }

    error_log('MCAS media upload error: ' . $e->getMessage());

    mcas_media_response(500, [
        'ok' => false,
        'message' => '撮影データを保存できませんでした。サーバーログを確認してください。',
    ]);
}