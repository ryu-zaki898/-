<?php
declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

mcas_require_login();

$pdo = mcas_db();
$userId = (int)$_SESSION['user_id'];
$role = (string)($_SESSION['role'] ?? '');
$tenantId = isset($_SESSION['tenant_id']) ? (int)$_SESSION['tenant_id'] : null;
$isSystemAdmin = $role === 'system_admin';
$isOrganizationAdmin = false;

if (!$isSystemAdmin && $tenantId !== null) {
    $stmt = $pdo->prepare(
        'SELECT 1 FROM organization_admins
         WHERE organization_id = :tenant_id AND user_id = :user_id LIMIT 1'
    );
    $stmt->execute([':tenant_id' => $tenantId, ':user_id' => $userId]);
    $isOrganizationAdmin = (bool)$stmt->fetchColumn();
}

if (!$isSystemAdmin && !$isOrganizationAdmin) {
    http_response_code(403);
    exit('利用者を管理する権限がありません。');
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        mcas_verify_csrf();

        $loginId = trim((string)($_POST['login_id'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $displayName = trim((string)($_POST['display_name'] ?? ''));
        $password = (string)($_POST['password'] ?? '');

        if (!preg_match('/^[A-Za-z0-9_.-]{4,100}$/', $loginId)) {
            throw new RuntimeException('ログインIDは半角英数字と _ . - の4〜100文字にしてください。');
        }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('メールアドレスの形式を確認してください。');
        }
        if ($displayName === '' || mb_strlen($displayName) > 100) {
            throw new RuntimeException('表示名を入力してください（100文字以内）。');
        }
        if (strlen($password) < 12) {
            throw new RuntimeException('パスワードは12文字以上にしてください。');
        }

        if ($isSystemAdmin) {
            $targetTenantId = filter_input(INPUT_POST, 'tenant_id', FILTER_VALIDATE_INT);
            $targetRole = (string)($_POST['role'] ?? 'user');

            if (!$targetTenantId || $targetTenantId < 1) {
                throw new RuntimeException('所属団体を選択してください。');
            }
            if (!in_array($targetRole, ['user', 'organization_admin'], true)) {
                throw new RuntimeException('指定された権限は設定できません。');
            }
        } else {
            $targetTenantId = $tenantId;
            $targetRole = 'user';
        }

        $stmt = $pdo->prepare(
            "INSERT INTO users
                (tenant_id, login_id, email, password_hash, display_name, role, is_active)
             VALUES
                (:tenant_id, :login_id, :email, :password_hash, :display_name, :role, 1)"
        );
        $stmt->execute([
            ':tenant_id' => $targetTenantId,
            ':login_id' => $loginId,
            ':email' => $email !== '' ? $email : null,
            ':password_hash' => password_hash($password, PASSWORD_DEFAULT),
            ':display_name' => $displayName,
            ':role' => $targetRole,
        ]);

        $newUserId = (int)$pdo->lastInsertId();

        if ($targetRole === 'organization_admin') {
            $stmt = $pdo->prepare(
                'INSERT INTO organization_admins (organization_id, user_id)
                 VALUES (:organization_id, :user_id)'
            );
            $stmt->execute([
                ':organization_id' => $targetTenantId,
                ':user_id' => $newUserId,
            ]);
        }

        $message = '利用者を作成しました。';
    } catch (Throwable $e) {
        $error = $e instanceof PDOException
            ? '利用者を作成できませんでした。ログインIDの重複などを確認してください。'
            : $e->getMessage();
    }
}

$organizations = [];
if ($isSystemAdmin) {
    $organizations = $pdo->query(
        "SELECT id, name FROM organizations WHERE status = 'approved' ORDER BY name"
    )->fetchAll();
}
?>
<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>利用者管理 - <?= mcas_e(MCAS_APP_NAME) ?></title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
<main class="mcas-container">
    <h1>利用者管理</h1>

    <?php if ($message !== ''): ?><p><?= mcas_e($message) ?></p><?php endif; ?>
    <?php if ($error !== ''): ?><p role="alert"><?= mcas_e($error) ?></p><?php endif; ?>

    <form method="post">
        <input type="hidden" name="csrf_token"
               value="<?= mcas_e(mcas_csrf_token()) ?>">

        <?php if ($isSystemAdmin): ?>
            <label>
                所属団体
                <select name="tenant_id" required>
                    <option value="">選択してください</option>
                    <?php foreach ($organizations as $organization): ?>
                        <option value="<?= (int)$organization['id'] ?>">
                            <?= mcas_e($organization['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>

            <label>
                権限
                <select name="role">
                    <option value="user">一般利用者</option>
                    <option value="organization_admin">団体管理者</option>
                </select>
            </label>
        <?php endif; ?>

        <label>ログインID
            <input name="login_id" maxlength="100" required>
        </label>
        <label>メールアドレス（任意）
            <input type="email" name="email" maxlength="254">
        </label>
        <label>表示名
            <input name="display_name" maxlength="100" required>
        </label>
        <label>初期パスワード（12文字以上）
            <input type="password" name="password" minlength="12"
                   autocomplete="new-password" required>
        </label>
        <button type="submit">利用者を作成</button>
    </form>
</main>
</body>
</html>